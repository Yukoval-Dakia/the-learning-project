import os,subprocess,sys
keep=['PATH','HOME','USER','LANG','TMPDIR']
env={k:os.environ[k] for k in keep if k in os.environ}
env.update(DATABASE_URL='postgres://docx@127.0.0.1:32770/docx', TEST_DATABASE_URL='postgres://docx@127.0.0.1:32770/docx', NODE_ENV='test', WORKFLOW_JUDGE_AUTO_ENROLL_ENABLED='false', WORKFLOW_JUDGE_OBSERVE_ENABLED='false', WORKFLOW_JUDGE_STUDENT_ANSWER_GRADING_ENABLED='false')
sys.exit(subprocess.call(['pnpm','--config.verify-deps-before-run=false',*sys.argv[1:]],env=env))
