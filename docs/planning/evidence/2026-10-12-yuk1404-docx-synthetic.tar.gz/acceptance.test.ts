import { readFileSync, writeFileSync } from 'node:fs';
import { eq, inArray } from 'drizzle-orm';
import { afterAll, expect, it, vi } from 'vitest';
import { memR2 } from '../../tests/helpers/r2';
const r2 = memR2();
vi.mock('@/server/r2', () => ({ getR2: () => r2 }));
import { db } from '@/db/client';
import { learning_session, question_block, question, knowledge, source_document, question_group_lifecycle } from '@/db/schema';
import { POST } from '@/capabilities/ingestion/api/docx';
import { ImportBody } from '@/capabilities/ingestion/api/import-schema';
import { completeIngestionImport } from '@/capabilities/ingestion/server/import-completion';
import { Ingestion } from '@/server/session';
import { getStartedBoss, getRunningBoss } from '@/server/boss/client';
import { structuredToPromptMarkdown } from '@/core/schema/structured_question';
let networkCalls = 0;
vi.stubGlobal('fetch', () => { networkCalls += 1; throw new Error('Network disabled for DOCX acceptance'); });
afterAll(async () => {
  await getRunningBoss()?.stop();
  await db.$client.end();
});
it('runs the synthetic DOCX through real converters, draft review and import', async () => {
  const boss = await getStartedBoss();
  await boss.createQueue('copilot_nudge_evaluate');
  const form = new FormData();
  form.append('file', new File([readFileSync('/tmp/yuk1404-docx/synthetic.docx')], 'synthetic.docx', {type:'application/vnd.openxmlformats-officedocument.wordprocessingml.document'}));
  const res = await POST(new Request('http://localhost/api/ingestion/docx', {method:'POST', body:form}));
  const receipt = await res.json();
  expect({status:res.status,receipt}).toMatchObject({status:201});
  const [session] = await db.select().from(learning_session).where(eq(learning_session.id, receipt.session_id));
  const blocks = await db.select().from(question_block).where(eq(question_block.ingestion_session_id, session.id)).orderBy(question_block.ordinal);
  const [source] = await db.select().from(source_document).where(eq(source_document.id, session.source_document_id!));
  expect(blocks.map(b=>b.structured?.question_no)).toEqual(['1','2','3','4','5','6','7']);
  expect(blocks[6].structured?.options?.map(o=>o.label)).toEqual(['A','B','C','D']);
  expect(blocks[0].image_refs).toEqual([]);
  expect(blocks[3].image_refs).toHaveLength(1);
  expect(source.body_md).toContain('自动甲');
  expect(session.warnings).toEqual([]);
  expect(session.status).toBe('extracted');
  const beforeFormal = (await db.select().from(question)).length;
  await db.insert(knowledge).values({id:'synthetic-kc',name:'合成验收知识点',domain:'yuwen',created_at:new Date(),updated_at:new Date(),version:0});
  await Ingestion.markReviewed(db, session.id);
  const imported = await completeIngestionImport(db, session.id, ImportBody.parse({blocks:blocks.map(b=>({
    block_id:b.id, source_block_ids:[b.id], page_spans:b.page_spans, image_refs:b.image_refs,
    final_prompt_md:structuredToPromptMarkdown(b.structured!), final_reference_md:null,
    final_wrong_answer_md:'', outcome:'unanswered', knowledge_ids:['synthetic-kc'], cause:null,
    question_kind:b.structured?.options?.length?'choice':'short_answer', difficulty:3,
  }))}));
  const formal = await db.select().from(question).where(inArray(question.id,imported.question_ids));
  const lifecycle = await db.select().from(question_group_lifecycle).where(inArray(question_group_lifecycle.group_id,imported.question_ids));
  const result = {
    fixture:'synthetic seven-question DOCX; not the school paper',
    converter:'real Pandoc + LibreOffice + PDFium',storage:'memory R2 substitute',database:'disposable local PostgreSQL',
    receipt,questionNumbers:blocks.map(b=>b.structured?.question_no),draftCount:blocks.length,
    draftOptions:blocks.map(b=>({no:b.structured?.question_no,options:b.structured?.options?.length??0,images:b.image_refs.length})),
    warnings:session.warnings,sourceMarkdownPreserved:!!source.body_md,
    formalBeforeWorker:beforeFormal,review:'markReviewed + explicit synthetic knowledge/kind',formalAfterManualImport:formal.length,
    formalChoices:formal.map(q=>({kind:q.kind,choices:q.choices_md,structuredOptions:q.structured?.options?.length??0})),
    answerable:lifecycle.filter(l=>l.scoring_admission_state==='admitted'&&l.availability==='general_pool').length,
    lifecycle:lifecycle.map(l=>({state:l.scoring_admission_state,reason:l.scoring_admission_withheld_reason,availability:l.availability})),
    networkCalls,providerCalls:0,
  };
  writeFileSync('/tmp/yuk1404-docx/acceptance.json',JSON.stringify(result,null,2));
  expect(formal).toHaveLength(7);
  expect(networkCalls).toBe(0);
});
