import { defineConfig } from 'vitest/config';
import { resolveConfig, sharedOxc } from '../../vitest.shared.ts';
export default defineConfig({resolve:resolveConfig,oxc:sharedOxc,test:{include:['src/capabilities/ingestion/api/import.db.test.ts'],testTimeout:30000,hookTimeout:30000}});
