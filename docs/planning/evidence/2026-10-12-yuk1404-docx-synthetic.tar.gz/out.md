非敏感合成边界样本

1\. 有空格的题干

A. 选项甲

B. 选项乙

2.没有空格的题干

A.甲 B.乙 C.丙 D.丁

3．全角句点题干

**4.** 图题同一段
<img src="./media/image1.png" style="width:1in;height:0.66667in" />

5\. 两图题干
<img src="./media/image1.png" style="width:1in;height:0.66667in" />
图间文字
<img src="./media/image1.png" style="width:1in;height:0.66667in" />
图后问题。

6\. 选项带图

A. 图甲
<img src="./media/image1.png" style="width:1in;height:0.66667in" />

7\. Word自动编号选项

1.  自动甲

2.  自动乙

3.  自动丙

4.  自动丁
