import { defineConfig } from 'vitest/config';
import { resolveConfig, sharedOxc } from '../../vitest.shared';
export default defineConfig({
  resolve: resolveConfig,
  oxc: sharedOxc,
  test: {
    include: ['.cache/yuk1404-docx/acceptance.test.ts'],
    testTimeout: 90000,
    hookTimeout: 30000,
  },
});
