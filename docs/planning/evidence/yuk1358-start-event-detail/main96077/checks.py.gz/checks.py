import subprocess, pathlib, json, os, time
root=pathlib.Path('/Volumes/YukovalSBak/yukoval-projects/tlp-yuk1352-start-frontdoor'); out=pathlib.Path('/tmp/yuk1358-event-main-integration'); env=dict(os.environ);env['PATH']='/Users/yuqi/.local/share/mise/installs/node/24.19.0/bin:'+env['PATH']
files=['server/start/event-client.unit.test.ts','server/start/event-read.unit.test.ts','src/capabilities/observability/server/event-detail.unit.test.ts','src/capabilities/observability/ui/event-detail-model.unit.test.ts','src/capabilities/observability/ui/EventDetailPage.interaction.unit.test.tsx','web/src/routes/EventDetailPage.start.unit.test.tsx','web/src/routes/AdminControls.start.unit.test.tsx','web/src/routes/AdminPages.start.unit.test.tsx','src/capabilities/composition.unit.test.ts','src/capabilities/observability/manifest.unit.test.ts','src/server/durable/prune-worker.unit.test.ts','tests/dbos-review-orphan/fixture-process.unit.test.ts','scripts/schema-migration-initialization.unit.test.ts']
assert all((root/f).exists() for f in files)
commands=[('unit',['pnpm','vitest','run','--config','vitest.unit.config.ts',*files]),('protocol',['node','--import','tsx','--test','tests/usability/start-rpc-fixtures.unit.spec.ts']),('typecheck',['pnpm','typecheck']),('lint',['pnpm','lint']),('build',['pnpm','build'])]
commands += [(x,['pnpm',x]) for x in ['audit:schema','audit:partition','audit:api-client','audit:api-client-usage','audit:capability-boundaries','audit:provider-lanes','audit:profile','audit:task-census','audit:draft-status','audit:draft-status-reads','audit:architecture-deepening']]
rows=[]
for name,cmd in commands:
 start=time.time();p=out/(name.replace(':','-')+'.log')
 with p.open('x') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'name':name,'command':cmd,'exitCode':r.returncode,'seconds':round(time.time()-start,2),'log':str(p)};rows.append(row);(out/'checks.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
