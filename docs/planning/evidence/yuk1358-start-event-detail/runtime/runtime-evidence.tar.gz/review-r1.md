# Independent R1 consequential review

Completed/noPending. P0: 0. P1: 1. No validated production-path P0/P1 defect found.

Workspace: `/Volumes/YukovalSBak/yukoval-projects/tlp-yuk1352-start-frontdoor`.
Branch: `feat/yuk-1358-start-event-detail`.
Exact reviewed head: `f1e4b9ef10334ca3949927706502d5d99f801328`.
Base: `74f648fad471b11a99c2e3339d7626ad5aa43e7a`.
Head tree: `b7043f2be77a9a38a6a631834f1396147f5d7977`.
Full diff SHA256: `43134749fe19312bdfc5a4b8f9b735b0d03720476a07e273d74758d3eff5ebbe`, computed from `git diff --no-ext-diff --no-color <base>..<head>`.
Source/test diff SHA256: `77d7531de176eca5f236f1168e3ce84130e632058ac7aaa3f878ba7d476cc961`, same command with `-- server src web tests`.

## P1: Correct the new DB test's expectation for the unchanged experimental reader

Location at the reviewed head: `server/start/event-operation.db.test.ts:117-119`, specifically line 119, `expect(result.event.cost_micro_usd).toBe(0)`.

The fixture seed at lines 53-66 uses the unregistered generic action `experimental:event_detail_fixture` and stores a zero cost. At `src/core/schema/event/experimental.ts:268-279`, the generic ExperimentalEvent schema has only action and payload. Its ordinary Zod object strips cost and task-run metadata. The event reader at `src/kernel/events/events.ts:104-117` spreads that parsed result and restores selected envelope fields, but does not restore cost_micro_usd or task_run_id. The unchanged public reader converts undefined omissions at `src/capabilities/observability/server/event-detail.ts:27-31` and returns that DTO at lines 35-50. The Start adapter delegates directly to this reader at `server/start/event-operation.ts:15`.

Therefore this seeded row's returned cost is undefined, even though its stored cost is zero. The new assertion cannot pass under the required real DB acceptance. This is a release blocker in the new test, not a defect introduced into the domain reader. Do not change the domain to satisfy the assertion. Check raw persisted metadata separately and assert the existing parsed DTO contract, or choose a supported typed fixture when testing that metadata's wire representation.

Reproduction reasoning: run the prepared scoped `server/start/event-operation.db.test.ts` in the parent's isolated DB boundary at this exact head. Its first test reaches the rich Tx read and expects zero where the production reader returns undefined. An earlier payload equality assertion may fail first because this fixture also passes unknown payload keys through the existing generic record parser. The cost mismatch alone is sufficient to prove the test cannot finish successfully. No test or DB operation was executed during this review.

A concurrent worktree repair to this test was observed during review. It changes these assertions but is outside the requested exact diff and does not close this finding for f1e4b9ef. Repair delivery and scoped DB verification remain parent-owned. This R1 report does not accept a replacement revision.

## Coverage and evidence limits

Read applicable AGENTS guidance and both supplied planning documents. Traced the actual server functions, canonical token/epoch gate, lazy operation loading, public event reads/writes and original HTTP resource wrapper; JSON-string read transport and browser error conversion; original correction controls, affected refs, query key/invalidation, busy guard, explicit retry:false, unknown-write/failed-refresh behavior; Start route generation, shell/back/document navigation and retained Vite adapter. The domain writer, manifest/HTTP semantics, schema/dependency files, shared boot and DBOS1394/0117 are unchanged by this diff.

Inspected rich authorization, client, page, protocol and prepared DB tests. Protocol coverage uses the installed Start client/Seroval resolution rather than a parallel serializer, but fixture transport and source-string route assertions do not establish live server/browser acceptance. Inspected the recorded 110-unit/11-protocol logs without rerunning them or accepting author claims as independent execution proof. Real DB, built RPC/browser, whole-table runtime no-write behavior, epoch transition behavior, deployment and CI remain parent-owned evidence layers.

Read-only review. No repository edits, git mutations, test/build execution, node_modules access, services, DB, Docker, browser, provider, Linear, GitHub, watch or delegation. The only written artifact is this report. No review work remains pending.
