# Independent R2 verification review

Completed/noPending. P0/P1 findings: NONE. Original R1 P1: RESOLVED at the reviewed repair head. No unresolved review objection remains. This is the final budgeted verification round for PR1623 / YUK1358.

## Exact scope and hashes

- Workspace: `/Volumes/YukovalSBak/yukoval-projects/tlp-yuk1352-start-frontdoor`.
- Branch: `feat/yuk-1358-start-event-detail`.
- R2 repair base, also R1 head: `f1e4b9ef10334ca3949927706502d5d99f801328`.
- Exact R2 head, confirmed as workspace HEAD: `4f36d3fc5b1d6b7249212572a1bce4dce4b7bcf0`.
- R2 head tree: `36ad929b897bacf0c57a2102019953a2c6fd0b12`.
- Repair full diff SHA256: `458cc51e62cfab7b3a91979c9badfb058bf606e375afc32ef3c7f7fd2bca2cbf`, from `git diff --no-ext-diff --no-color f1e4b9ef10334ca3949927706502d5d99f801328 4f36d3fc5b1d6b7249212572a1bce4dce4b7bcf0`.
- Repair source/test diff SHA256: `34247eaf1e18b0a4ec30be3bbb020ca886a9da32b3b772d2982ddad81d6ac20f`, using the same command with `-- server src web tests`.
- Repair full binary diff SHA256: `fddff546c5e3acbc391bb188cfff1b40749971520ab99525e698951917a71d4f`, from `git diff --binary --full-index --no-ext-diff --no-textconv <R2-base> <R2-head>`. This includes the compressed evidence additions.

Original R1 scope was `74f648fad471b11a99c2e3339d7626ad5aa43e7a..f1e4b9ef10334ca3949927706502d5d99f801328`. Its supplied full diff SHA256 `43134749fe19312bdfc5a4b8f9b735b0d03720476a07e273d74758d3eff5ebbe` was independently recomputed and matches. For provenance, the current PR range `74f648fad471b11a99c2e3339d7626ad5aa43e7a..4f36d3fc5b1d6b7249212572a1bce4dce4b7bcf0` has full diff SHA256 `b90b10669d0530b4b33db869dcf1410277da8350097093b03b2f85308e3d8b0f` under the same non-binary command. R2 reviews the repair and its regression implications; it does not restart an unlimited full review of that range.

## Original finding resolved

R1 identified an impossible expected public cost of zero for the generic `experimental:event_detail_fixture` row, with a related raw-payload/public-projection mismatch. The repair in `server/start/event-operation.db.test.ts:118-131` now queries the actual transaction's stored row. It asserts full raw payload equality, stored cost `0`, and stored task ID `task_original`. The fixture remains rich and unchanged, including the own top-level `__proto__` key, long Unicode text, nested ambiguity, arrays and false/null/zero values at `server/start/event-test-fixtures.ts:6-13`.

The public payload expectation now calls the existing `parseEvent` on that action and payload. This respects the actual reader rather than inventing a replacement projection. `src/core/schema/event/index.ts:107-142` selects the existing union and generic branch; `src/core/schema/event/experimental.ts:268-279` declares only action and payload. The kernel applies `parseEvent` at `src/kernel/events/events.ts:104` and restores its listed envelope fields at lines 105-117, without restoring task or cost. The public DTO at `src/capabilities/observability/server/event-detail.ts:27-50` omits undefined values. Therefore the new explicit public cost/task expectations of undefined are correct for this generic fixture. The existing writer validates with `parseEvent` but persists the original payload and metadata at `src/kernel/events/events.ts:239-274`, which explains why the raw assertions must remain separate.

The repair does not change the kernel, schema or public operation to satisfy a test. All production TS/TSX is byte-identical between R1 and R2. The complete repair changes only this DB test plus planning/handoff documents and parent evidence. The test has 14 added lines and two removed lines. Its workspace copy matches the pinned head.

## Standards and spec verification

P0/P1 standards findings: NONE. P0/P1 spec findings: NONE. The added schema import is confined to the test and derives the expectation from the existing domain contract. No new product behavior, domain/schema/dependency/DBOS change, mock of the parser, skipped test or reduced fixture was introduced.

The new expected projection retains equality to the real `readEventDetail(tx, 'focus')` at test line 117. Exact ISO time and positive dispatch sequence remain asserted. The cause, two effects, multiple ordered corrections and marked-wrong status remain checked at lines 133-146. Original row bytes, whole-table Tx snapshots, independent Db isolation and rollback snapshots remain checked at lines 147-153. The unchanged remaining tests retain all four correction kinds, fresh IDs, canonical receipts, original bytes and transaction isolation; token/epoch/input/replacement rejections with whole-table and sequence snapshots; and corrupt focal/causal/correction data returning 500 without writes.

Raw stored keys and public DTO serialization have distinct checks. The unchanged client unit test at `server/start/event-client.unit.test.ts:39-42` compares the entire DTO and its JSON representation and explicitly checks an own `__proto__` key already present in a supplied public payload. Correcting the DB fixture's kernel projection does not weaken that transport assertion. The Start production adapters, authorization order, UI controls/navigation, query invalidation and no-automatic-replay behavior remain unchanged from R1's reviewed production source.

## Evidence and limits

Read the supplied R1 report, applicable root and nested AGENTS guidance, the authorized consumer plan, `docs/planning/2026-10-09-yuk1358-start-event-detail-parent.md`, and the exact-head parent manifest and gzip evidence. All ten manifest entries match both compressed SHA256 and decompressed-content SHA256. The retained parent logs show two separate runs with 14 passing tests and one failure, first for payload equality and then undefined versus zero cost, followed by two files and 15 passing tests. The census records the baseline distinction between raw and parsed keys. The parent document reports passing repair typecheck and focused Biome; the stored outputs contain the two tsc commands and Biome's one-file/no-fixes result. Author 110-unit/11-protocol evidence remains separate from the parent's recorded 15 DB tests.

These are inspected parent artifacts, not independently executed tests or independently observed runtime behavior. Hash agreement proves artifact integrity against the manifest, not runtime acceptance or execution provenance by itself. No DB, Docker, runtime, browser, provider, test, build or install operation was performed in R2. Real built RPC/browser acceptance and exact-head CI remain separate pending evidence owned by the parent. No merge, deployment or whole-migration acceptance is claimed.

Read-only repository review. No repository edits, git mutations, Linear/GitHub/watch actions or delegation. The other child's ignored `.cache/yuk1358-event-built-acceptance` files and runtime lock owner `otherthread1394` were not touched. The only written artifact is `/tmp/yuk1358-start-event-detail-review-r2.md`. No review work remains pending.
