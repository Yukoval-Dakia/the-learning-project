import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,realpathSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {ROOT,hash,digest,assertReadOnly,assertNoSecrets} from './common.mjs';
export function browserWindow(mode,before,after,observer){
 assert(['list','navigation'].includes(mode));assert.equal(observer.id,'d46ae889bb07e441420d7371ed91168e3c1497e326c9ebdf797836c0494395ff');
 const origin=new URL(observer.origin);assert.equal(origin.hostname,'127.0.0.1');assert.equal(origin.protocol,'http:');assert(origin.port);
 const mutations=observer.observations.filter(o=>!['GET','HEAD'].includes(o.method));
 const changed=Object.keys(before.tables).filter(k=>digest(before.tables[k])!==digest(after.tables[k]));
 if(mode==='list'){assertReadOnly(before,after);assert.equal(mutations.length,0,'LIST observer detected mutation');}
 return {scope:mode==='list'?'bounded LIST no-write window':'navigation only; independent retained route effects',no_write:mode==='list',changed_tables:changed,observed_mutations:mutations,observed_count:observer.observations.length,visible_ui:'parent evidence required',original_transport_faults:observer.observations.filter(o=>o.fault).map(o=>({sequence:o.sequence,fault:o.fault,status:o.status??null})),before_sha256:digest(before),after_sha256:digest(after)};
}
if(process.argv[1]&&resolve(process.argv[1])===new URL(import.meta.url).pathname){
 const [mode,b,a,o,out]=process.argv.slice(2);assert.equal(process.argv.length,7);
 const run=realpathSync(dirname(b));assert(run.startsWith(ROOT+'/.cache/yuk1358-notes-built-acceptance/runs/'));
 for(const file of [a,o,out])assert.equal(realpathSync(dirname(file)),run);
 const read=file=>JSON.parse(readFileSync(file,'utf8')),receipt=browserWindow(mode,read(b),read(a),read(o));
 const bytes=JSON.stringify({...receipt,evidence:[b,a,o].map(file=>({file:resolve(file),sha256:hash(readFileSync(file))}))},null,2)+'\n';assertNoSecrets(bytes,[]);writeFileSync(out,bytes,{flag:'wx'});
}
