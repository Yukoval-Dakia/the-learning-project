import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {hash,digest,fieldCensus,assertReadOnly} from './common.mjs';
import {CUSTOM,EMPTY,BOUNDARY,activeNotes,summary} from './fixture.mjs';
export async function runAcceptance({app,host,x,seal,write,snapshot,lock,log}){
 const {serve}=await import('@hono/node-server');
 const {serverFnFetcher}=await import(pathToFileURL(seal.build.framework.fetcher));
 const {runWithStartContext}=await import(pathToFileURL(seal.build.framework.storage));
 const base=`http://127.0.0.1:${x.http_port}`,id=seal.build.functions.getStartNoteList;
 const server=serve({fetch:app.fetch,hostname:'127.0.0.1',port:x.http_port});
 await new Promise((resolve,reject)=>{server.once('listening',resolve);server.once('error',reject);});
 let calls=0,windows=0;
 async function ro(name,fn){lock();const label=`read-${++windows}-${name}`,before=await snapshot(`${label}-before`);let result,error;try{result=await fn();}catch(e){error=e;}const after=await snapshot(`${label}-after`);assertReadOnly(before,after);write(`${label}-no-write.json`,{equal:true,all_nonsystem_tables:Object.keys(before.tables).length,all_sequence_count:Object.keys(before.sequences).length,sha256:digest(before)});if(error)throw error;return result;}
 async function rpc(data,{status=200,token,epoch}={}){
  lock();let wire,envelope,error;
  const headers=token===null?{}:{'x-internal-token':token??x.token};
  const transport=async(url,init)=>{const target=new URL(url,base);assert.equal(target.origin,base);assert.equal(target.pathname,`/_serverFn/${id}`);const req=new Request(target,init);assert.equal(req.method,'GET');const call=++calls;const response=await fetch(req),body=await response.clone().text();wire={call,id,method:'GET',path:target.pathname,status:response.status,response_headers:Object.fromEntries(response.headers),response_body:body,response_sha256:hash(body),token_class:token===null?'missing':token?'wrong':'valid',data,transport:'installed serverFnFetcher and untouched generated resolver via real loopback TCP'};log(wire);write(`rpc-${call}-wire.json`,wire);return response;};
  try{envelope=await runWithStartContext({startOptions:{},request:new Request(base),handlerType:'serverFn',contextAfterGlobalMiddlewares:{},executedRequestMiddlewares:new Set(),getRouter(){throw Error('no client router');}},()=>serverFnFetcher(`${base}/_serverFn/${id}`,[{method:'GET',data,headers,fetch:transport}],transport));}catch(e){error=e;}
  assert.equal(wire?.status,status,'actual RPC status');
  if(status!==200){const body=JSON.parse(wire.response_body);assert.equal(body.error,{401:'unauthorized',503:'contract_epoch_fenced',400:'validation_error'}[status]);if(epoch)assert.equal(body.state,epoch);return body;}
  if(error)throw error;assert.equal(wire.response_headers['x-tss-serialized'],'true');assert(envelope&&Object.hasOwn(envelope,'result'));assert.equal(envelope.error,undefined);
  // Notes returns a structured DTO, unlike the older event GET JSON-string result.
  const result=envelope.result;assert(result&&Array.isArray(result.rows));write(`rpc-${wire.call}-decoded.json`,{result});return result;
 }
 async function http(data,status=200){const params=new URLSearchParams();for(const [k,v]of Object.entries(data))if(v!==undefined)params.set(k,v);const path=`/api/notes?${params}`,response=await fetch(base+path,{headers:{'x-internal-token':x.token}}),body=await response.json();assert.equal(response.status,status);log({kind:'retained HTTP parity',path,status:response.status,body});return body;}
 async function parity(data,ids){const actual=await rpc(data),canonical=JSON.parse(JSON.stringify(await host.publicList(data))),legacy=await http(data);fieldCensus(actual,canonical);fieldCensus(actual,legacy);const expected=activeNotes().filter(n=>ids===undefined||ids.includes(n.id)).map(summary);fieldCensus(actual,{rows:expected});for(const row of actual.rows)assert.equal(new Date(row.updated_at).toISOString(),row.updated_at);return actual;}
 async function epoch(kind){lock();const before=await snapshot(`epoch-${kind}-before`),receipt=await host.epoch(kind),after=await snapshot(`epoch-${kind}-after`);for(const k of ['schemas','relations','columns','constraints','sequences','migrations'])assert.deepEqual(after[k],before[k]);assert.deepEqual(Object.keys(before.tables).filter(k=>digest(before.tables[k])!==digest(after.tables[k])),['public.contract_epoch']);write(`epoch-${kind}-receipt.json`,{...receipt,classification:'explicit phase setup outside read windows'});}
 const ids=(...names)=>names.map(n=>`y1358n_${n}`),invalid=[null,{},'bad',[],{subject:''},{subject:' '},{subject:7},{query:''},{query:' \n '},{query:7},{query:'边'.repeat(201)}];
 try{
  await epoch('begin_prepare');
  await ro('auth-before-validation-and-epoch',async()=>{for(const token of [null,'wrong-synthetic-rpc-token'])for(const input of [null,{query:''},{}])await rpc(input,{status:401,token});});
  await ro('preparing503',async()=>{for(const input of [null,{query:''},{}])await rpc(input,{status:503,epoch:'preparing'});});
  await epoch('mark_ready');await ro('ready503',async()=>{for(const input of [null,{query:''},{}])await rpc(input,{status:503,epoch:'ready'});});
  await epoch('activate');
  await ro('invalid-blank-over200',async()=>{for(const input of invalid.filter(v=>!(v&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).length===0)))await rpc(input,{status:400});for(const input of [{subject:''},{subject:' '},{query:''},{query:' \n '},{query:'边'.repeat(201)}]){assert.deepEqual(await http(input,400),{error:'validation_error'});}});
  await ro('unfiltered-unpaginated-full-iso',async()=>{const all=await parity({});assert(all.rows.length>200);assert.equal(all.rows.length,216);assert.deepEqual(new Set(all.rows.map(r=>r.type)),new Set(['note_atomic','note_hub','note_long']));});
  await ro('unknown-empty-custom-alias-inherited',async()=>{
   for(const subject of ['yuwen','wenyan','classical_chinese','  wenyan  '])await parity({subject},ids('language'));
   await parity({subject:CUSTOM},ids('custom'));await parity({subject:EMPTY},[]);await parity({subject:`unknown'"%_\\ α🙂`},[]);await parity({subject:'unknown-empty'},[]);
   await parity({subject:'math'},ids('math','percent','underscore','slash','decoy'));await parity({subject:'physics'},[]);
  });
  await ro('escaped-title-body-and-filters',async()=>{
   for(const [data,names]of [[{query:'NEEDLE'},['language','custom','math']],[{query:'  NEEDLE  ',subject:'wenyan'},['language']],[{query:'深层正文',subject:CUSTOM},['custom']],[{query:'深层正文',subject:'math'},[]],[{query:'75%'},['percent']],[{query:'a_b'},['underscore']],[{query:'path\\leaf'},['slash']],[{query:'%_'},['language','custom']],[{query:'%_',subject:'wenyan'},['language']],[{query:'%_',subject:'math'},[]],[{query:'a_b',subject:'math'},['underscore']],[{query:'75%',subject:CUSTOM},[]],[{query:'path\\leaf',subject:'math'},['slash']],[{query:'<script>原文</script>',subject:'wenyan'},['language']],[{query:'no-such-evidence'},[]]])await parity(data,ids(...names));
   await parity({query:BOUNDARY},ids(...Array.from({length:205},(_,i)=>`bulk_${i}`)));
  });
  await ro('real-preserved-subjects-http',async()=>{const response=await fetch(base+'/api/subjects',{headers:{'x-internal-token':x.token}}),body=await response.json();assert.equal(response.status,200);assert(Array.isArray(body.subjects));for(const subject of [CUSTOM,EMPTY,'math','yuwen','physics'])assert(body.subjects.some(s=>s.id===subject));assert(!body.subjects.some(s=>s.id==='general'));write('rpc-subjects-http.json',{status:response.status,body,preserved_http_consumer:true});});
  write('rpc-summary.json',{calls,read_windows:windows,explicit_writes:0,all_nonsystem_and_sequences:true,paid_counter:0,browser:'UNRUN separate parent acceptance'});
 }finally{server.closeAllConnections?.();await new Promise(resolve=>server.close(resolve));}
}
