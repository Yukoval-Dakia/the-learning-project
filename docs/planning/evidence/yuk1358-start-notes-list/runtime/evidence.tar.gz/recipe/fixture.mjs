import assert from 'node:assert/strict';
import {hash} from './common.mjs';
export const CUSTOM='subj_y1358nscience',EMPTY='subj_y1358nempty';
export const BOUNDARY='边'.repeat(200),LONG='深层正文 <script>原文</script> %_ \\ 条件未决 α🙂\n'.repeat(240);
const T=Date.parse('2026-10-09T12:34:56.789Z');
const body={type:'doc',content:[{type:'paragraph',attrs:{id:'block-rich',semantic_kind:'definition',source_markdown:LONG},content:[{type:'text',text:LONG},{type:'text',text:'deep nested evidence',marks:[{type:'bold'}]}]}]};
export function fixtureNotes(){
 let index=0;
 const make=(id,override={})=>({id:`y1358n_${id}`,type:'note_atomic',title:`Synthetic ${id}`,knowledge_ids:[],intent_source:'user',source:'manual',generation_status:'ready',verification_status:'not_required',version:17,body_blocks:null,attrs:{nested:{values:[null,false,0],ambiguity:['A','B']}},created_at:new Date(T).toISOString(),updated_at:new Date(T+1000+(++index)).toISOString(),archived_at:null,...override});
 const notes=[
 make('language',{type:'note_long',title:'Title needle %_ α🙂 <script>原文</script>',knowledge_ids:['y1358n_language_child','missing-label'],body_blocks:body,verification_status:'verified',version:21}),
 make('custom',{type:'note_hub',title:'Custom needle',knowledge_ids:['y1358n_custom_child'],body_blocks:body,generation_status:'pending',verification_status:'unverified'}),
 make('math',{title:'Title needle only',knowledge_ids:['y1358n_math'],version:0}),
 make('archived_label',{knowledge_ids:['y1358n_archived']}),make('cutoff',{knowledge_ids:['y1358n_cutoff']}),
 make('seed_only',{knowledge_ids:['seed:yuwen:root']}),make('unlabeled',{title:'Unlabeled aXb 75X decoy'}),
 make('percent',{title:'literal 75% complete',knowledge_ids:['y1358n_math']}),
 make('underscore',{title:'literal a_b',knowledge_ids:['y1358n_math']}),
 make('slash',{title:'literal path\\leaf',knowledge_ids:['y1358n_math']}),
 make('decoy',{title:'literal aXb 75X complete pathXleaf',knowledge_ids:['y1358n_math']}),
 make('archived_note',{archived_at:new Date(T).toISOString(),knowledge_ids:['y1358n_language_child']}),
 make('interactive',{type:'interactive',knowledge_ids:['y1358n_language_child']}),
 make('quiz',{type:'tool_quiz',knowledge_ids:['y1358n_language_child']}),
 ];
 for(let i=0;i<205;i++)notes.push(make(`bulk_${i}`,{title:`${i}:${BOUNDARY}`,updated_at:new Date(T+i).toISOString()}));
 return notes;
}
export function summary(n){return Object.fromEntries(['id','type','title','knowledge_ids','generation_status','verification_status','version','updated_at'].map(k=>[k,n[k]]));}
export const activeNotes=()=>fixtureNotes().filter(n=>n.archived_at===null&&['note_atomic','note_hub','note_long'].includes(n.type)).sort((a,b)=>b.updated_at.localeCompare(a.updated_at));
export async function seedFixture(host,owner){
 const sql=host.sql;
 for(const [id,name] of [[CUSTOM,'Synthetic science'],[EMPTY,'Synthetic empty']]){
  await sql`insert into subject(id,display_name,display_name_norm,origin,is_selectable,revision,created_at,updated_at) values (${id},${name},${name.toLowerCase()},'custom',true,0,${new Date(T).toISOString()}::timestamptz,${new Date(T).toISOString()}::timestamptz)`;
  await sql`insert into subject_name_claim(name_norm,subject_id,kind,created_at) values (${name.toLowerCase()},${id},'canonical',${new Date(T).toISOString()}::timestamptz)`;
  await sql`insert into subject_trait_binding(subject_id,trait_kind,trait_id) select ${id},trait_kind,trait_id from subject_trait_binding where subject_id='general'`;
 }
 const knowledge=[['language_parent','wenyan',null,null],['language_child',null,'y1358n_language_parent',null],['custom_parent',CUSTOM,null,null],['custom_child',null,'y1358n_custom_parent',null],['archived_parent','wenyan',null,new Date(T).toISOString()],['cutoff',null,'y1358n_archived_parent',null],['archived','wenyan',null,new Date(T).toISOString()],['math','math',null,null]];
 for(const [id,domain,parent,archived] of knowledge)await sql`insert into knowledge(id,name,domain,parent_id,archived_at,created_at,updated_at) values (${`y1358n_${id}`},${`Synthetic knowledge ${id}`},${domain},${parent},${archived}::timestamptz,${new Date(T).toISOString()}::timestamptz,${new Date(T).toISOString()}::timestamptz)`;
 const notes=fixtureNotes();
 for(const n of notes)await sql`insert into artifact(id,type,title,knowledge_ids,intent_source,source,body_blocks,attrs,generation_status,verification_status,version,archived_at,created_at,updated_at) values (${n.id},${n.type},${n.title},${JSON.stringify(n.knowledge_ids)}::jsonb,${n.intent_source},${n.source},${n.body_blocks===null?null:JSON.stringify(n.body_blocks)}::jsonb,${JSON.stringify(n.attrs)}::jsonb,${n.generation_status},${n.verification_status},${n.version},${n.archived_at}::timestamptz,${n.created_at}::timestamptz,${n.updated_at}::timestamptz)`;
 const hydrated=await host.hydrate();assert(hydrated);
 return {owner,custom_subject:CUSTOM,empty_subject:EMPTY,knowledge_ids:knowledge.map(r=>`y1358n_${r[0]}`),notes_count:notes.length,active_count:activeNotes().length,notes_sha256:hash(JSON.stringify(notes)),rich_body_sha256:hash(JSON.stringify(body)),paid_counter:0,scope:'synthetic SQL seed outside read windows; explicit JSON.stringify avoids postgres-js disabled JSON serializers; real built migrator owns builtin roots/traits'};
}
