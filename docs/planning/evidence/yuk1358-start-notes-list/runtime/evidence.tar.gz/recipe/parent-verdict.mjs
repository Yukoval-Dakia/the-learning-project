import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,existsSync,realpathSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {ROOT,hash,assertNoSecrets} from './common.mjs';
import {browserWindow} from './browser-verdict.mjs';
export const CASES=['cold-token-gate','subjects-http-custom','search-debounce250','search-clear','empty-search','empty-subject','loading','error-restored-retry','refresh','wrong-token-regate','note-detail-navigation','knowledge-navigation'];
export function checkCases(cases){assert.deepEqual(cases.map(c=>c.id).sort(),[...CASES].sort());for(const c of cases){assert.equal(c.accepted,true,c.id);assert.equal(c.observed,true,c.id);assert(Array.isArray(c.evidence)&&c.evidence.length>0,c.id);if(c.id==='error-restored-retry')assert.equal(c.real_transport_restored_before_retry,true);}}
if(process.argv[1]&&resolve(process.argv[1])===new URL(import.meta.url).pathname){
 const [dir]=process.argv.slice(2);assert.equal(process.argv.length,3);const run=realpathSync(dir);assert(run.startsWith(ROOT+'/.cache/yuk1358-notes-built-acceptance/runs/'));const read=n=>JSON.parse(readFileSync(join(run,n),'utf8'));
 assert(!existsSync(join(run,'egress-denied.json')),'egress denial is failed acceptance');
 const rpc=read('rpc-summary.json');assert(rpc.calls>0&&rpc.read_windows>0);assert.equal(rpc.explicit_writes,0);assert.equal(rpc.paid_counter,0);
 assert(read('rpc-pass.json'));assert.equal(read('migrator-receipt.json').exit,0);assert(read('cleanup.json').removed_exact_owned_container);
 assert.deepEqual(read('shared-after.json'),read('shared-before.json'));
 const browser=read('browser-parent-verdict.json');checkCases(browser.cases);
 const evidence={};for(const c of browser.cases)for(const name of c.evidence){assert(/^[a-z0-9-]+\.(json|png|webm)$/.test(name));const file=join(run,name);assert.equal(realpathSync(file),file);evidence[name]=hash(readFileSync(file));if(name.endsWith('.json'))assertNoSecrets(readFileSync(file,'utf8'),[]);}
 for(const c of browser.cases){
  assert(c.window&&['before','after','observer'].every(k=>/^[a-z0-9-]+\.json$/.test(c.window[k])),'each browser case needs actual bounded window');
  for(const name of Object.values(c.window))assert(c.evidence.includes(name),'window must be hashed evidence');
  const receipt=browserWindow(c.id.endsWith('navigation')?'navigation':'list',read(c.window.before),read(c.window.after),read(c.window.observer));
  if(!c.id.endsWith('navigation'))assert(receipt.no_write);
 }
 const verdict={head:'c236a7160343f7f9a6277ec8c59b70e104ebf267',status:'PARENT-OBSERVED-ISOLATED-ACCEPTANCE',rpc,browser,evidence,canonical_boot:false,deployed:false,provider_acceptance:false,navigation_is_separate:true};
 const bytes=JSON.stringify(verdict,null,2)+'\n';assertNoSecrets(bytes,[]);writeFileSync(join(run,'parent-verdict.json'),bytes,{flag:'wx'});
}
