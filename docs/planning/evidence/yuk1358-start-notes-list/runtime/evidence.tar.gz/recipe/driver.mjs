import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { randomBytes, randomUUID } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, readdirSync, realpathSync, statSync, writeFileSync, appendFileSync } from 'node:fs';
import { dirname, join, relative } from 'node:path';
import { createRequire, Module, syncBuiltinESMExports } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';
import net from 'node:net';
import tls from 'node:tls';
import dgram from 'node:dgram';
import { ROOT, BRANCH, PREPARED_HEAD, PREPARED_SOURCE_HEAD, hash, digest, parseMap, checkLock } from './common.mjs';
import { transformHost } from './host-transform.mjs';
import { seedFixture } from './fixture.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
const [mode, run, label] = process.argv.slice(2);
assert(['offline', 'seal', 'verify', 'setup', 'seed', 'rpc', 'serve', 'snapshot', 'compare', 'cleanup', 'package', 'dump'].includes(mode));
assert.equal(process.argv.length, ['snapshot', 'compare'].includes(mode) ? (mode === 'compare' ? 6 : 5) : ['offline', 'seal', 'verify'].includes(mode) ? 3 : 4);
if (run) assert(/^[a-z0-9][a-z0-9-]{0,63}$/.test(run));
if (label) assert(/^[a-z0-9][a-z0-9-]{0,63}$/.test(label));
const RUN = run ? join(HERE, 'runs', run) : null;
const c = {
  authorized: process.env.YUK1358_PARENT_ACCEPTANCE,
  owner: process.env.YUK1358_LOCK_OWNER, token: process.env.YUK1358_LOCK_TOKEN,
  record: process.env.YUK1358_LOCK_RECORD, recordHash: process.env.YUK1358_LOCK_RECORD_SHA256,
  ownerField: process.env.YUK1358_LOCK_OWNER_FIELD, tokenField: process.env.YUK1358_LOCK_TOKEN_FIELD,
  image: process.env.YUK1358_PG_IMAGE_ID, docker: process.env.DOCKER_HOST,
  original4: process.env.YUK1358_ORIGINAL4_IDS, release: process.env.YUK1358_RELEASE_RECORD,
};
const clean = Object.fromEntries(['PATH', 'TMPDIR', 'LANG', 'LC_ALL'].filter(k => process.env[k]).map(k => [k, process.env[k]]));
for (const key of Object.keys(process.env)) delete process.env[key];
Object.assign(process.env, clean, { NODE_ENV: 'production', RW_WORKER: '0', GIT_OPTIONAL_LOCKS: '0' });
if (c.docker) process.env.DOCKER_HOST = c.docker;
const pause = ms => new Promise(r => setTimeout(r, ms));
const write = (name, value) => writeFileSync(join(RUN, name), JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
const read = name => JSON.parse(readFileSync(join(RUN, name), 'utf8'));
function cmd(exe, args, timeout = 30000) {
  const r = spawnSync(exe, args, { cwd: ROOT, env: process.env, encoding: 'utf8', timeout, maxBuffer: 32 * 1024 * 1024 });
  assert(!r.error && r.status === 0, `${exe} ${args[0]} failed; preserve failure and inspect command output privately`);
  return r.stdout.trim();
}
function files(dir) {
  return readdirSync(join(ROOT, dir)).sort().flatMap(n => {
    const p = join(dir, n); const s = statSync(join(ROOT, p));
    assert.equal(realpathSync(join(ROOT, p)), join(ROOT, p), 'artifact symlink refused');
    return s.isDirectory() ? files(p) : [p];
  });
}
function manifest(paths) { return Object.fromEntries(paths.sort().map(p => [p, hash(readFileSync(join(ROOT, p)))])); }
const docsOnly = p => /^(docs\/|\.remember\/|PLAN\.md$|README\.md$|MEMORY\.md$)/.test(p);
function source() {
  assert.equal(realpathSync(process.cwd()), ROOT);
  const head = cmd('git', ['rev-parse', 'HEAD']);
  assert.equal(cmd('git', ['branch', '--show-current']), BRANCH);
  const documentationAdvance=cmd('git',['diff','--name-only','-z',PREPARED_HEAD,head]).split('\0').filter(Boolean);
  assert(documentationAdvance.every(docsOnly),'candidate source differs from c236');
  if(!['offline','seal','verify'].includes(mode))assert.equal(head,PREPARED_HEAD,'runtime requires exact c236 HEAD; offline docs-only advance is not execution authorization');
  const tracked = cmd('git', ['ls-tree','-r','--name-only','-z',PREPARED_HEAD]).split('\0').filter(p => p && !docsOnly(p));
  const dirty = cmd('git', ['diff', 'HEAD', '--name-only','-z']).split('\0').filter(Boolean);
  assert(dirty.every(docsOnly), 'tracked product dirty');
  const extra = cmd('git', ['ls-files', '--others', '--exclude-standard','-z']).split('\0').filter(Boolean);
  assert(extra.every(docsOnly), 'untracked product files refused');
  cmd('git', ['check-ignore', join(HERE, 'driver.mjs')]);
  const all = manifest(tracked);
  return { candidate: PREPARED_HEAD, source_baseline:PREPARED_SOURCE_HEAD, parent_test_only_repairs:[], observed_head: head, exact_head_ready:head===PREPARED_HEAD, documentation_advance:documentationAdvance, branch: BRANCH, files: all, sha256: digest(all), node: process.version,
    permitted_later_commits: 'none: exact parent HEAD; source frozen at c236; no product mutations' };
}
function framework() {
  const client = realpathSync(fileURLToPath(import.meta.resolve('@tanstack/react-start/client-rpc')));
  const startRequire = createRequire(client);
  const core = startRequire.resolve('@tanstack/start-client-core/package.json');
  const fetcher = join(dirname(core), 'dist/esm/client-rpc/serverFnFetcher.js');
  const r = createRequire(core);
  const storage = r.resolve('@tanstack/start-storage-context/package.json');
  const serovalEntry = r.resolve('seroval');
  let serovalPackage = dirname(serovalEntry); while (!existsSync(join(serovalPackage,'package.json'))) { const up=dirname(serovalPackage); assert.notEqual(up,serovalPackage); serovalPackage=up; }
  const router = r.resolve('@tanstack/router-core/package.json');
  const pluginEntry=createRequire(router).resolve('seroval-plugins/web');
  let pluginPackage=dirname(pluginEntry); while(!existsSync(join(pluginPackage,'package.json'))){const up=dirname(pluginPackage);assert.notEqual(up,pluginPackage);pluginPackage=up;}
  const serovalEsm = join(serovalPackage,JSON.parse(readFileSync(join(serovalPackage,'package.json'),'utf8')).exports['.'].import);
  function implementationFiles(dir) { return readdirSync(dir).sort().flatMap(n=>{const p=join(dir,n);return statSync(p).isDirectory()?implementationFiles(p):/\.(js|mjs|cjs)$/.test(n)?[p]:[];}); }
  const paths = [...implementationFiles(join(dirname(core),'dist/esm')), ...implementationFiles(join(dirname(router),'dist/esm')), ...implementationFiles(pluginPackage), join(pluginPackage,'package.json'), ...implementationFiles(serovalPackage), ...implementationFiles(dirname(storage)), serovalEsm, router, client, core, join(serovalPackage,'package.json'), fetcher, serovalEntry, join(dirname(core), 'dist/esm/getDefaultSerovalPlugins.js'), join(dirname(storage), 'dist/esm/index.js')];
  return { fetcher, storage: join(dirname(storage),'dist/esm/index.js'), files: Object.fromEntries([...new Set(paths)].map(p => [relative(ROOT, p), hash(readFileSync(p))])) };
}
function build() {
  const paths = ['dist/server.cjs', ...files('dist/start'), ...files('web/dist')];
  const resolvers = paths.filter(p => /server-fn-resolver.*\.js$/.test(p)); assert.equal(resolvers.length, 1);
  function shaManifest(path) {
    return Object.fromEntries(readFileSync(join(ROOT,path),'utf8').trim().split('\n').map(line=>{const m=line.match(/^([a-f0-9]{64})  (.+)$/);assert(m,'invalid SHA manifest');return [m[2],m[1]];}));
  }
  const author=shaManifest('.cache/yuk1358-notes-list/artifacts-sha256.txt');
  assert.equal(Object.keys(author).length,893,'frozen artifact census');
  const allEmitted=manifest([...files('dist'),...files('web/dist')]);
  assert.deepEqual(allEmitted,author,'all frozen 893 artifacts');
  const sourceAuthor=shaManifest('.cache/yuk1358-notes-list/source-sha256.txt');
  const authorLogs=shaManifest('.cache/yuk1358-notes-list/logs-sha256.txt');
  for(const [p,h] of Object.entries(authorLogs))assert.equal(hash(readFileSync(join(ROOT,'.cache/yuk1358-notes-list',p))),h,`author log drift ${p}`);
  for(const [p,h] of Object.entries(sourceAuthor)) assert.equal(hash(readFileSync(join(ROOT,p))),h,`author source drift ${p}`);
  const transformed = transformHost(readFileSync(join(ROOT, 'dist/server.cjs'), 'utf8'));
  const dbChunks = paths.filter(p => p.startsWith('dist/start/server/assets/') && p.endsWith('.js') && readFileSync(join(ROOT,p),'utf8').includes('//#region src/db/client.ts'));
  assert.equal(dbChunks.length,1);
  const dbText = readFileSync(join(ROOT,dbChunks[0]),'utf8');
  const alias = dbText.match(/export \{[^}]*\bdb as (\w+)[^}]*\}/)?.[1]; assert(alias);
  return { author_manifest: { source_sha256:digest(sourceAuthor), artifact_sha256:digest(author), artifact_count:Object.keys(author).length, commands_sha256:hash(readFileSync(join(ROOT,'.cache/yuk1358-notes-list/commands.json'))), logs_manifest_sha256:hash(readFileSync(join(ROOT,'.cache/yuk1358-notes-list/logs-sha256.txt'))), logs:authorLogs,note:'original author command/log bytes sealed only; no check/build rerun by preparer' }, esm_db: { path: dbChunks[0], export: alias }, files: allEmitted, sha256: digest(allEmitted), resolver: resolvers[0], functions: parseMap(readFileSync(join(ROOT, resolvers[0]), 'utf8')), framework: framework(), host: transformed.proof };
}
function recipe() {
  return Object.fromEntries(readdirSync(HERE).filter(n => /\.(mjs|md|js|cjs|sh|example)$/.test(n)).sort().map(n => [n, hash(readFileSync(join(HERE, n)))]));
}
function immutable() {
  const seal = JSON.parse(readFileSync(join(HERE, 'seal.json')));
  assert.equal(source().sha256, seal.source.sha256, 'source drift after seal');
  assert.equal(source().candidate, seal.source.candidate);
  assert.deepEqual(recipe(), seal.recipe, 'recipe drift after seal');
  assert.deepEqual(build(), seal.build, 'build/dependencies drift after seal');
  return seal;
}
function authorized() {
  checkLock(c);
  assert(Number(process.versions.node.split('.')[0]) >= 24, 'Node >=24 required');
  assert(c.docker?.startsWith('unix://') && existsSync(c.docker.slice(7)), 'explicit local Docker socket required');
}
function state() {
  const x = read('private-state.json'); assert.equal(x.run, run); assert.equal(x.root, ROOT);
  assert.equal(x.lock_hash, c.recordHash); assert.equal(x.lock_token_hash, hash(c.token)); assert.equal(x.lock_owner, c.owner);
  assert(/^sha256:[a-f0-9]{64}$/.test(x.image)); assert(/^[a-f0-9]{64}$/.test(x.container));
  assert(Number.isInteger(x.http_port) && x.http_port>1024 && x.http_port<65536); assert.notEqual(x.port,x.http_port);
  assert(/^y1358n_[a-f0-9]{32}$/.test(x.database));
  for (const url of [x.admin_url, x.app_url]) {
    const u = new URL(url); assert.equal(u.hostname, '127.0.0.1'); assert.equal(u.pathname, `/${x.database}`);
    assert.equal(Number(u.port), x.port); assert(![5432, 18994, 18995, 18952].includes(x.port));
  }
  return x;
}
function owned(x) {
  checkLock(c);
  const info = JSON.parse(cmd('docker', ['inspect', x.container]))[0];
  assert.equal(info.Id, x.container); assert.equal(info.Image, x.image);
  assert.equal(info.Config.Labels['yuk1358.noteslist.owner'], x.owner);
  assert.equal(info.Config.Labels['yuk1358.noteslist.lock'], x.lock_token_hash);
  assert.equal(info.Config.Labels['yuk1358.noteslist.run'],run);
  assert(!info.HostConfig.Binds?.length,'no shared bind storage');
  assert(info.Mounts.every(m=>m.Type==='tmpfs'),'no attached volume/shared storage');
  assert(Object.hasOwn(info.HostConfig.Tmpfs,'/var/lib/postgresql/data'),'owned tmpfs PGDATA missing');
  const binding = info.HostConfig.PortBindings['5432/tcp'];
  assert.equal(binding[0].HostIp, '127.0.0.1');
  if (x.port) assert.equal(Number(info.NetworkSettings.Ports['5432/tcp'][0].HostPort), x.port);
  return info;
}
async function connection(x, identity = true) {
  owned(x);
  const { default: postgres } = await import('postgres');
  const client = postgres(x.admin_url, { max: 1, ssl: false, connect_timeout: 5, idle_timeout: 5, onnotice() {} });
  try {
    if (identity) {
      const [row] = await client`select current_database() as db, owner_id from yuk1358_noteslist.identity`;
      assert.equal(row.db, x.database); assert.equal(row.owner_id, x.owner);
    }
    return client;
  } catch (e) { await client.end({ timeout: 3 }); throw e; }
}
export async function snapshot(client, name) {
  const result = await client.begin('isolation level repeatable read read only', async tx => {
    const relations = await tx`select n.nspname as schema,c.relname as name,c.relkind as kind,
      case when c.relkind in ('v','m') then pg_get_viewdef(c.oid,true) when c.relkind in ('i','I') then pg_get_indexdef(c.oid) else null end as definition
      from pg_class c join pg_namespace n on n.oid=c.relnamespace
      where n.nspname not in ('pg_catalog','information_schema') and n.nspname not like 'pg_toast%' and n.nspname not like 'pg_temp%' order by 1,2`;
    const columns = await tx`select table_schema,table_name,column_name,data_type,udt_name,is_nullable,column_default,ordinal_position
      from information_schema.columns where table_schema not in ('pg_catalog','information_schema') order by 1,2,8`;
    const constraints = await tx`select n.nspname as schema,c.relname as relation,k.conname as name,pg_get_constraintdef(k.oid,true) as definition
      from pg_constraint k join pg_class c on c.oid=k.conrelid join pg_namespace n on n.oid=c.relnamespace
      where n.nspname not in ('pg_catalog','information_schema') order by 1,2,3`;
    const tables = {}, sequences = {};
    for (const r of relations) {
      const key = `${r.schema}.${r.name}`;
      if (r.kind === 'S') sequences[key] = await tx`select last_value::text,is_called from ${tx(r.schema)}.${tx(r.name)}`;
      if (['r','p','m'].includes(r.kind)) {
        const captured = await tx`select to_jsonb(t) as row,to_jsonb(t)::text as frozen_bytes from ${tx(r.schema)}.${tx(r.name)} t order by to_jsonb(t)::text`;
        const rows=Array.from(captured,r=>r.row), frozen_bytes=Array.from(captured,r=>r.frozen_bytes);
        tables[key] = { count: rows.length, sha256: digest(rows), rows, frozen_bytes };
      }
    }
    const [boss] = await tx`select to_regnamespace('pgboss') is not null as present`;
    const count = relations.filter(r => r.schema === 'public' && ['r','p'].includes(r.kind)).length;
    const schemas=await tx`select nspname as name from pg_namespace where nspname not in ('pg_catalog','information_schema') and nspname not like 'pg_%' order by 1`;
    const journal=JSON.parse(readFileSync(join(ROOT,'drizzle/meta/_journal.json'),'utf8'));
    const applied=Array.from(await tx`select hash from drizzle.__drizzle_migrations order by id`,r=>r.hash);
    const expected=journal.entries.map(e=>hash(readFileSync(join(ROOT,`drizzle/${e.tag}.sql`))));
    assert.deepEqual(applied,expected,'actual migrated journal must match all sealed SQL including 0116');
    assert(!boss.present);
    return { schemas, relations, columns, constraints, tables, sequences, public_table_count: count, boss: boss.present, migrations: journal.entries.map((e,i)=>({tag:e.tag,hash:expected[i]})) };
  });
  write(`${name}.json`, { ...result, captured_at: new Date().toISOString(), sha256: digest(result) }); return result;
}
function sharedSnapshot() {
  checkLock(c);
  const selected=(c.original4??'').split(',');
  assert.equal(selected.length,4,'parent must name original four full container IDs');
  assert.equal(new Set(selected).size,4);assert(selected.every(id=>/^[a-f0-9]{64}$/.test(id)));
  assert(c.release?.startsWith('/')&&realpathSync(c.release)===c.release&&statSync(c.release).isFile(),'parent must name current-release record');
  const running=cmd('docker',['ps','--no-trunc','--format','{{.ID}}']).split('\n').filter(Boolean).sort();
  assert(selected.every(id=>running.includes(id)),'original four must be running');
  const original4=selected.sort().map(id=>{const item=JSON.parse(cmd('docker',['inspect',id]))[0];return {id:item.Id,image:item.Image,started_at:item.State.StartedAt,status:item.State.Status,health:item.State.Health?.Status??null};});
  return {running,original4,release:{path:c.release,sha256:hash(readFileSync(c.release))},lock:checkLock(c)};
}
function validateShared() {
  const after=sharedSnapshot();write('shared-after.json',after);assert.deepEqual(after,read('shared-before.json'),'original4/running set/release/lock drift; parent must retain mutex and investigate');
}
async function setup(seal) {
  mkdirSync(join(HERE, 'runs'), { recursive: true }); mkdirSync(RUN);
  write('shared-before.json',sharedSnapshot());
  write('setup-started.json', { head: source().observed_head, lock: checkLock(c), build: seal.build.sha256 });
  assert(/^sha256:[a-f0-9]{64}$/.test(c.image ?? ''), 'parent must pin locally installed PG image ID; driver never pulls');
  write('docker-preflight.json', { version: cmd('docker',['version','--format','{{json .}}']), image:c.image, endpoint:'explicit local unix socket', no_pull:true });
  const info = JSON.parse(cmd('docker', ['image', 'inspect', c.image]))[0]; assert.equal(info.Id, c.image);
  assert(info.Config.Env.includes('PGDATA=/var/lib/postgresql/data'),'parent must pin local PG/pgvector image using this declared tmpfs PGDATA');
  const owner = randomUUID(); const database = `y1358n_${randomUUID().replaceAll('-', '')}`;
  const password = randomBytes(24).toString('hex'); const appPassword = randomBytes(24).toString('hex');
  writeFileSync(join(RUN, 'postgres.env'), `POSTGRES_DB=${database}\nPOSTGRES_USER=y1358n_seed\nPOSTGRES_PASSWORD=${password}\n`, { flag: 'wx' });
  write('setup-intent.json', { owner, database, image: c.image, lock_token_hash: hash(c.token) });
  const container = cmd('docker', ['create', '--pull=never', '--name', `yuk1358-notes-${run}-${owner.slice(0,8)}`, '--tmpfs','/var/lib/postgresql/data:rw', '--label', `yuk1358.noteslist.run=${run}`, '--label', `yuk1358.noteslist.owner=${owner}`, '--label', `yuk1358.noteslist.lock=${hash(c.token)}`,
    '-p', '127.0.0.1::5432', '--env-file', join(RUN, 'postgres.env'), c.image]);
  const initial = { root: ROOT, run, owner, database, container, image: c.image, lock_owner: c.owner, lock_hash: c.recordHash, lock_token_hash: hash(c.token) };
  write('owned-container.json', initial); owned(initial); cmd('docker', ['start', container]);
  const live = JSON.parse(cmd('docker', ['inspect', container]))[0];
  const port = Number(live.NetworkSettings.Ports['5432/tcp'][0].HostPort);
  const x = { ...initial, port, admin_url: `postgres://y1358n_seed:${password}@127.0.0.1:${port}/${database}`, app_url: `postgres://y1358n_app:${appPassword}@127.0.0.1:${port}/${database}`, token: randomBytes(32).toString('hex'), http_port: await availablePort(port) };
  write('private-state.json', x); writeFileSync(join(RUN, 'browser-token.txt'), x.token + '\n', { flag: 'wx' });
  writeFileSync(join(RUN,'synthetic-app.env'), `DATABASE_URL=${x.app_url}\nINTERNAL_TOKEN=${x.token}\nAPI_PORT=${x.http_port}\nNODE_ENV=production\nRW_WORKER=0\n`, {flag:'wx'}); state();
  let ready = false;
  for (let i = 0; i < 60; i++) {
    checkLock(c); const r = spawnSync('docker', ['exec', container, 'pg_isready', '-h', '127.0.0.1', '-U', 'y1358n_seed', '-d', database], { env: process.env, timeout: 1500 });
    if (r.status === 0) { ready = true; break; } await pause(500);
  }
  assert(ready, 'isolated PG startup deadline exceeded; cleanup exact owned resource');
  denyExternalNetwork(x);
  const client = await connection(x, false);
  try {
    const migrated=spawnSync(process.execPath,[join(HERE,'migrator-runner.cjs')],{cwd:ROOT,env:{...process.env,DATABASE_URL:x.admin_url,YUK1358_PG_PORT:String(x.port)},encoding:'utf8',timeout:120000,maxBuffer:32*1024*1024});
    const migratorLog=(migrated.stdout??'')+'\n'+(migrated.stderr??'');
    writeFileSync(join(RUN,'private-migrator.log'),migratorLog,{flag:'wx'});
    write('migrator-receipt.json',{bundle_sha256:seal.build.files['dist/migrate.cjs'],log_sha256:hash(migratorLog),exit:migrated.status,signal:migrated.signal,real_built_migrator:true,logs_private:true});
    assert(!migrated.error&&migrated.status===0,'real emitted migrator failed; inspect private log, never rerun in place');
    await client.unsafe('create schema yuk1358_noteslist'); await client.unsafe('create table yuk1358_noteslist.identity(owner_id text primary key)');
    await client`insert into yuk1358_noteslist.identity values (${owner})`;
    await client.unsafe(`CREATE ROLE y1358n_app LOGIN PASSWORD '${appPassword}'`);
    await client.unsafe("ALTER ROLE y1358n_app SET statement_timeout = '15s'");
    await client.unsafe("ALTER ROLE y1358n_app SET lock_timeout = '5s'");
    await client.unsafe(`REVOKE CREATE ON DATABASE "${database}" FROM PUBLIC, y1358n_app`);
    await client.unsafe('REVOKE CREATE ON SCHEMA public FROM PUBLIC, y1358n_app');
    await client.unsafe(`GRANT CONNECT ON DATABASE "${database}" TO y1358n_app`);
    await client.unsafe('GRANT USAGE ON SCHEMA public TO y1358n_app');
    await client.unsafe('GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA public TO y1358n_app');
    await client.unsafe('GRANT USAGE,SELECT,UPDATE ON ALL SEQUENCES IN SCHEMA public TO y1358n_app');
    await snapshot(client, 'setup-baseline');
  } finally { await client.end({ timeout: 3 }); }
  write('setup-ready.json', { image: c.image, port, database, no_ryuk_worker_listener: true });
}
async function availablePort(pgPort) {
  const probe=net.createServer(); probe.listen({host:'127.0.0.1',port:0});
  await new Promise((r,j)=>{probe.once('listening',r);probe.once('error',j);});
  const port=probe.address().port; await new Promise(r=>probe.close(r));
  assert(port!==pgPort && port>1024); return port;
}
async function seed(x) {
  assert(existsSync(join(RUN,'setup-ready.json'))); write('seed-started.json',{at:new Date().toISOString()});
  const {host}=await loadHost(x,immutable());
  try {
    const fixture=await seedFixture(host,x.owner); write('seed.json',fixture);
    for(const kind of ['begin_prepare','mark_ready','activate']) await host.epoch(kind);
    write('seed-epoch.json',{epoch:host.codeEpoch,state:'active',transitions:3});
    const client=await connection(x); try { await snapshot(client,'seed-baseline'); } finally { await client.end({timeout:3}); }
  } finally { await host.close(); }
}
async function loadHost(x, seal) {
  process.env.DATABASE_URL = x.app_url; process.env.INTERNAL_TOKEN = x.token; process.env.API_PORT = String(x.http_port);
  process.env.RW_STATIC_DIR = 'web/dist';
  // No environment-file loader runs in the transformed entry. Credentials can only be synthetic.
  assert(!Object.keys(process.env).some(k => /API_KEY|AUTH_TOKEN|PROXY|LAMINAR|OTEL|NODE_OPTIONS/.test(k)));
  const filename = join(ROOT, 'dist/server.cjs'); const transformed = transformHost(readFileSync(filename, 'utf8'));
  assert.deepEqual(transformed.proof, seal.build.host);
  writeFileSync(join(RUN, `host-${mode}.cjs`), transformed.code, { flag: 'wx' });
  write(`host-${mode}-proof.json`, transformed.proof);
  // Use the original filename for require and relative dynamic imports. No product file is changed.
  const m = new Module(filename); m.filename = filename; m.paths = Module._nodeModulePaths(dirname(filename));
  m._compile(transformed.code, filename); const host = m.exports;
  let app,esm;
  try { app=await host.initialize(); esm=await import(pathToFileURL(join(ROOT,seal.build.esm_db.path))); }
  catch(error){await host.close();throw error;}
  const esmDb = esm[seal.build.esm_db.export]; assert(esmDb?.$client);
  const close = host.close; host.close = async () => { await esmDb.$client.end({ timeout:3 }); await close(); };
  return { host, app };
}
function denyExternalNetwork(x) {
  // This applies to source seed imports, emitted host modules and lazy Start chunks.
  // Admit only exact isolated PG and loopback RPC ports; browser HTTP is inbound.
  let blocked=0; const reject=message=>{ blocked++; if(RUN&&existsSync(RUN)&&!existsSync(join(RUN,'egress-denied.json'))) write('egress-denied.json',{blocked,paid_counter:0,message}); throw new Error(message); };
  const connect = net.Socket.prototype.connect;
  net.Socket.prototype.connect = function(...args) {
    let options = args[0];
    if (Array.isArray(options)) options = options[0];
    if (typeof options === 'number') options = { port: options, host: typeof args[1] === 'string' ? args[1] : 'localhost' };
    if(!(options && typeof options==='object' && [x.port,x.http_port].includes(Number(options.port)) && options.host==='127.0.0.1')) return reject('outbound TCP forbidden: only isolated PG and HTTP loopback');
    return connect.apply(this, args);
  };
  tls.connect = () => reject('TLS/provider connection forbidden in notes-list acceptance');
  const fetch = globalThis.fetch;
  globalThis.fetch = (input, init) => { const u = new URL(input instanceof Request ? input.url : input); if(u.origin!==`http://127.0.0.1:${x.http_port}`)return reject('external fetch forbidden'); return fetch(input, init); };
  dgram.createSocket = () => reject('UDP/DNS socket forbidden');
  syncBuiltinESMExports();
  globalThis.setInterval = () => reject('background interval forbidden in notes-list acceptance');
}
async function serve(x, seal) {
  assert(existsSync(join(RUN, 'rpc-pass.json')), 'finish RPC before opening browser listener');
  write('serve-started.json', { pid: process.pid, bound: '127.0.0.1', port: x.http_port, no_background_listener: true });
  const { host, app } = await loadHost(x, seal);
  const { serve } = await import('@hono/node-server');
  const csp = "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; connect-src 'self'; media-src 'self' blob:; object-src 'none'; frame-src 'none'; worker-src 'none'; form-action 'self'; base-uri 'self'";
  const guardedFetch = async request => { const res = await app.fetch(request); const headers = new Headers(res.headers); headers.set('Content-Security-Policy', csp); headers.set('X-DNS-Prefetch-Control', 'off'); return new Response(res.body, {status:res.status, statusText:res.statusText, headers}); };
  let server;
  try { server=serve({fetch:guardedFetch,hostname:'127.0.0.1',port:x.http_port}); await new Promise((resolve,reject)=>{server.once('error',reject);server.once('listening',resolve);}); }
  catch(error){server?.close();await host.close();throw error;}
  let stop = false; process.once('SIGINT', () => { stop = true; }); process.once('SIGTERM', () => { stop = true; });
  write('serve-ready.json', { pid: process.pid, emitted_host_sha256:seal.build.host.transformed_sha256, start_sha256:seal.build.sha256, origin: `http://127.0.0.1:${x.http_port}` });
  try {
    const deadline = Date.now() + 45 * 60 * 1000;
    while (!stop && !existsSync(join(RUN, 'stop-serve.request')) && Date.now() < deadline) { checkLock(c); await pause(500); }
  } finally {
    server.closeAllConnections?.(); await new Promise(r => server.close(r)); await host.close();
    write('serve-stopped.json', { pid: process.pid, owned_handle_only: true });
  }
}
async function cleanup() {
  // Cleanup deliberately tolerates source/build drift, but never lock/identity drift.
  if (existsSync(join(RUN, 'serve-ready.json')) && !existsSync(join(RUN, 'serve-stopped.json'))) {
    if (!existsSync(join(RUN, 'stop-serve.request'))) write('stop-serve.request', { requested: true });
    for (let i = 0; i < 60 && !existsSync(join(RUN, 'serve-stopped.json')); i++) { checkLock(c); await pause(250); }
    assert(existsSync(join(RUN, 'serve-stopped.json')), 'serve owner absent; no saved-PID kill allowed');
  }
  if (existsSync(join(RUN,'cleanup.json'))) throw new Error('cleanup already recorded; preserve receipt');
  assert(existsSync(join(RUN,'private-state.json')) || existsSync(join(RUN,'owned-container.json')), 'container identity outcome unknown; parent must inspect exact setup-intent labels, never reset run');
  const x = existsSync(join(RUN, 'private-state.json')) ? state() : read('owned-container.json');
  owned(x); cmd('docker', ['rm', '-f', x.container]);
  const ids = cmd('docker', ['ps', '-a', '--no-trunc', '--format', '{{.ID}}']).split('\n'); assert(!ids.includes(x.container));
  validateShared();
  write('cleanup.json', { removed_exact_owned_container: x.container, lock_released: false, other_resources_touched: false });
}
async function packageEvidence(x) {
  const { assertNoSecrets,publicEvidenceName }=await import('./common.mjs');
  const entries={};
  assert(!existsSync(join(RUN,'egress-denied.json')),'egress denial forbids acceptance packaging');
  const secrets=[x.token,x.admin_url,x.app_url,new URL(x.admin_url).password,new URL(x.app_url).password,c.token];
  for(const name of readdirSync(RUN).sort()) if(publicEvidenceName(name)) {
    const bytes=readFileSync(join(RUN,name),'utf8'); assertNoSecrets(bytes,secrets); entries[name]={sha256:hash(bytes),bytes:Buffer.byteLength(bytes)};
  }
  assert(Object.keys(entries).length>0);
  const output=join(RUN,'public-evidence'); mkdirSync(output);
  for(const name of Object.keys(entries)) writeFileSync(join(output,name),readFileSync(join(RUN,name)),{flag:'wx'});
  writeFileSync(join(output,'manifest.json'),JSON.stringify({entries,source:immutable().source.sha256,build:immutable().build.sha256,paid_counter:0,claim:'evidence only; no automatic browser or runtime PASS'},null,2)+'\n',{flag:'wx'});
}
async function main() {
  if (mode === 'offline') { const s = source(); console.log(JSON.stringify({ status: 'offline-recipe-only', head: s.observed_head, source_sha256: s.sha256, build_read_or_sealed: false, runtime_executed: false })); return; }
  if (mode === 'seal') {
    // Offline only: parse/hash existing frozen artifacts, never build/evaluate/start them.
    const s = source(); const b = build(); const again = build(); assert.deepEqual(again, b, 'build changed during seal'); assert.equal(source().sha256,s.sha256,'source changed during seal');
    writeFileSync(join(HERE, 'seal.json'), JSON.stringify({ source: s, build: b, recipe: recipe(), at: new Date().toISOString(), runtime_executed: false }, null, 2) + '\n', { flag: 'wx' });
    console.log(JSON.stringify({ status: 'offline-sealed-only', head: s.observed_head, build_sha256: b.sha256 })); return;
  }
  if (mode === 'verify') { const s = immutable(); console.log(JSON.stringify({ status: 'offline-verified-only', candidate: s.source.candidate, head: source().observed_head, exact_head_ready:source().exact_head_ready, build_sha256: s.build.sha256, runtime_executed: false })); return; }
  authorized();
  if (mode === 'cleanup') { await cleanup(); return; }
  const seal = immutable();
  if (mode === 'setup') { await setup(seal); return; }
  const x = state(); assert(existsSync(join(RUN, 'setup-ready.json')));
  denyExternalNetwork(x);
  if (existsSync(join(RUN,`failure-${mode}.json`))) throw new Error('failed phase preserved; use a new run after exact owned cleanup');
  if (mode === 'seed') { assert(!existsSync(join(RUN,'seed-started.json')), 'seed already attempted; do not replay'); await seed(x); }
  if (mode === 'rpc') {
    assert(existsSync(join(RUN, 'seed.json'))); assert(!existsSync(join(RUN,'rpc-started.json')), 'RPC phase already attempted; preserve failed evidence'); write('rpc-started.json', { at: new Date().toISOString(), head: source().observed_head });
    const { runAcceptance } = await import('./rpc.mjs'); const client = await connection(x);
    let host;
    try { const loaded = await loadHost(x, seal); host = loaded.host;
      await runAcceptance({ ...loaded, client, x, seal, fixture: read('seed.json'), write, snapshot: name => snapshot(client, name), lock: () => checkLock(c), log: record => appendFileSync(join(RUN, 'wire.jsonl'), JSON.stringify(record) + '\n') });
      write('rpc-pass.json', { scope: 'actual loopback built notes-list RPC and retained emitted host/domain; isolated bootstrap', head: source().observed_head, build: seal.build.sha256, browser: 'separate parent acceptance required', provider_calls: 0, paid_counter: 0 });
    } finally { if (host) await host.close(); await client.end({ timeout: 3 }); }
  }
  if (mode === 'serve') await serve(x, seal);
  if (mode === 'package') await packageEvidence(x);
  if (mode === 'dump') { owned(x); const data=cmd('docker',['exec',x.container,'pg_dump','-U','y1358n_seed','-d',x.database,'--no-owner','--no-acl']); writeFileSync(join(RUN,'synthetic-dump.sql'),data,{flag:'wx'}); write('dump-receipt.json',{sha256:hash(data),scope:'explicit parent request synthetic database only'}); }
  if (mode === 'compare') { const other = process.argv[5]; assert(/^[a-z0-9][a-z0-9-]{0,63}$/.test(other)); const { assertReadOnly } = await import('./common.mjs'); assertReadOnly(read(`${label}.json`), read(`${other}.json`)); write(`compare-${label}-${other}.json`, { equal: true, public_tables: read(`${label}.json`).public_table_count, scope: 'only the manually bounded window between these snapshots' }); }
  if (mode === 'snapshot') { const client = await connection(x); try { await snapshot(client, label); } finally { await client.end({ timeout: 3 }); } }
}
main().catch(error => {
  // Avoid exposing URLs/token/passwords through stdout. Detailed failure stays private in ignored run.
  let message = String(error?.stack ?? error);
  if (RUN && existsSync(join(RUN, 'private-state.json'))) {
    const x = read('private-state.json'); for (const v of [c.token,x.token, x.admin_url, x.app_url, new URL(x.admin_url).password, new URL(x.app_url).password]) message = message.replaceAll(v, '[synthetic-secret]');
  }
  if (RUN && existsSync(RUN) && !existsSync(join(RUN, `failure-${mode}.json`))) write(`failure-${mode}.json`, { message, accepted: false });
  console.error(RUN ? `${mode} failed. Acceptance is incomplete. Inspect the ignored failure receipt; do not retry writes.` : message); process.exitCode = 1;
});
