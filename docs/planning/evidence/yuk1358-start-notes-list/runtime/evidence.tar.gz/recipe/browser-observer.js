// Install through T3 preview evaluation on this isolated origin only.
(() => {
 if(window.y1358NotesObserver)throw Error('already installed');
 if(location.protocol!=='http:'||location.hostname!=='127.0.0.1'||!location.port)throw Error('isolated loopback only');
 const ID='d46ae889bb07e441420d7371ed91168e3c1497e326c9ebdf797836c0494395ff',path=`/_serverFn/${ID}`,original=window.fetch,origin=location.origin,observations=[],inputs=[],rules=[];let sequence=0;
 const inputListener=e=>{if(e.target?.getAttribute?.('aria-label')==='搜索笔记')inputs.push({at:performance.now(),value:e.target.value});};
 document.addEventListener('input',inputListener,true);
 window.fetch=async function(input,init){
  const req=new Request(input,init),url=new URL(req.url);if(url.origin!==origin)throw TypeError('observer external fetch denied');
  const obs={sequence:++sequence,path:url.pathname,method:req.method,at:performance.now(),started_at:new Date().toISOString()};observations.push(obs);
  if(url.pathname===path)obs.serialized_request_payload=url.searchParams.get('payload');
  const rule=rules.find(r=>url.pathname===path&&r.remaining>0);if(rule)rule.remaining--;
  if(rule?.kind==='wrong-token')req.headers.set('x-internal-token','wrong-synthetic-browser-token');
  if(rule?.kind==='before-send'){obs.sent=false;obs.fault=rule.kind;obs.transport_error=true;throw TypeError('controlled observer failure before send');}
  if(rule?.kind==='hold-before-send'){obs.fault=rule.kind;obs.held=true;await new Promise(resolve=>{rule.release=resolve;});obs.held=false;}
  obs.sent=true;
  try{const res=await original.call(this,req);obs.status=res.status;obs.received_at=performance.now();obs.serialized=res.headers.get('x-tss-serialized');
   if(url.pathname===path||url.pathname==='/api/subjects')obs.actual_response_body=await res.clone().text();
   if(rule?.kind==='after-response'){obs.fault=rule.kind;obs.transport_error=true;throw TypeError('controlled observer failure after real response');}
   return res;
  }catch(error){obs.transport_error=true;obs.ended_at=performance.now();throw error;}
 };
 const api={
  arm(kind,count=1){if(!['wrong-token','before-send','after-response','hold-before-send'].includes(kind)||!Number.isInteger(count)||count<1||count>4)throw Error('bounded notes GET fault required');rules.push({kind,remaining:count});},
  release(){for(const rule of rules){rule.release?.();delete rule.release;}},
  export(){return JSON.parse(JSON.stringify({origin,id:ID,observations,inputs,rules:rules.map(({release,...r})=>r),clock:new Date().toISOString()}));},
  restore(){api.release();rules.length=0;window.fetch=original;document.removeEventListener('input',inputListener,true);delete window.y1358NotesObserver;return {real_transport_restored:true};}
 };
 window.y1358NotesObserver=api;
})();
