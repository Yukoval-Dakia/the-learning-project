// OFFLINE only. Checks helpers, hashes source/artifacts, never evaluates product code.
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {readFileSync,readdirSync,writeFileSync,existsSync} from 'node:fs';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {ROOT,hash} from './common.mjs';
import {transformHost} from './host-transform.mjs';
const HERE=dirname(fileURLToPath(import.meta.url)),NODE='/Users/yuqi/.local/share/mise/installs/node/24.19.0/bin/node';
const suffix=process.argv[2]??'';assert(suffix===''||/^[a-z0-9-]+$/.test(suffix));const prefix=suffix?suffix+'-':'';
assert.equal(process.cwd(),ROOT);assert(!existsSync(join(HERE,prefix+'offline-checks.json')),'preserve prior command logs');
const env={PATH:process.env.PATH,LANG:'C',GIT_OPTIONAL_LOCKS:'0'},commands=[];
function check(exe,args,name){const log=prefix+name;const result=spawnSync(exe,args,{cwd:ROOT,env,encoding:'utf8',timeout:60000,maxBuffer:4*1024*1024});const bytes=(result.stdout??'')+(result.stderr??'');writeFileSync(join(HERE,log),bytes,{flag:'wx'});commands.push({command:[exe,...args],exit:result.status,signal:result.signal,error:result.error?.message??null,log,sha256:hash(bytes)});return !result.error&&result.status===0;}
let passed=true;
for(const file of readdirSync(HERE).filter(n=>/\.(js|mjs|cjs)$/.test(n)).sort())passed=check(NODE,['--check',join(HERE,file)],`check-${file}.log`)&&passed;
passed=check('bash',['-n',join(HERE,'parent-run.sh')],'check-parent-run.log')&&passed;
const transformed=transformHost(readFileSync(join(ROOT,'dist/server.cjs'),'utf8'));
if(existsSync(join(HERE,'host-syntax.cjs')))assert.equal(hash(readFileSync(join(HERE,'host-syntax.cjs'))),hash(transformed.code));else writeFileSync(join(HERE,'host-syntax.cjs'),transformed.code,{flag:'wx'});writeFileSync(join(HERE,prefix+'host-syntax-proof.json'),JSON.stringify(transformed.proof,null,2)+'\n',{flag:'wx'});
passed=check(NODE,['--check',join(HERE,'host-syntax.cjs')],'check-host-syntax.log')&&passed;
passed=check(NODE,['--test',join(HERE,'offline.test.mjs')],'offline-tests.log')&&passed;
if(passed)passed=check('bash',[join(HERE,'parent-run.sh'),'seal'],'seal.log')&&passed;
if(passed)passed=check('bash',[join(HERE,'parent-run.sh'),'verify'],'verify.log')&&passed;
writeFileSync(join(HERE,prefix+'offline-checks.json'),JSON.stringify({status:passed?'OFFLINE-PASS':'OFFLINE-FAIL',commands,product_entrypoint_evaluated:false,runtime_database_browser_network:false,node:process.version,at:new Date().toISOString()},null,2)+'\n',{flag:'wx'});
assert(passed,'offline helper check failed; preserve logs and fix own files only');
console.log(JSON.stringify({status:'OFFLINE-PASS',commands:commands.length,runtime:'UNRUN'}));
