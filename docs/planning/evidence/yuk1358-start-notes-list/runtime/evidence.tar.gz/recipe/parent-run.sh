#!/bin/bash
set -euo pipefail
umask 077
cd /Volumes/YukovalSBak/yukoval-projects/tlp-yuk1352-start-frontdoor
if [[ "${1:-}" != offline && "${1:-}" != seal && "${1:-}" != verify ]]; then
  : "${YUK1358_PARENT_ENV_FILE:?Parent must supply an ignored private acceptance env file}"
  [[ "$YUK1358_PARENT_ENV_FILE" == /Volumes/YukovalSBak/yukoval-projects/tlp-yuk1352-start-frontdoor/.cache/yuk1358-notes-built-acceptance/* ]]
  [[ -f "$YUK1358_PARENT_ENV_FILE" && ! -L "$YUK1358_PARENT_ENV_FILE" ]]
  git check-ignore -q "$YUK1358_PARENT_ENV_FILE"
  set -a
  source "$YUK1358_PARENT_ENV_FILE"
  set +a
fi
# Strip application/provider/proxy/preload settings before loading Node or any emitted module.
exec /usr/bin/env -i \
  PATH="$PATH" TMPDIR="${TMPDIR:-/tmp}" LANG="${LANG:-C}" NODE_ENV=production \
  DOCKER_HOST="${DOCKER_HOST:-}" \
  YUK1358_PARENT_ACCEPTANCE="${YUK1358_PARENT_ACCEPTANCE:-}" \
  YUK1358_LOCK_OWNER="${YUK1358_LOCK_OWNER:-}" YUK1358_LOCK_TOKEN="${YUK1358_LOCK_TOKEN:-}" \
  YUK1358_LOCK_RECORD="${YUK1358_LOCK_RECORD:-}" YUK1358_LOCK_RECORD_SHA256="${YUK1358_LOCK_RECORD_SHA256:-}" \
  YUK1358_LOCK_OWNER_FIELD="${YUK1358_LOCK_OWNER_FIELD:-}" YUK1358_LOCK_TOKEN_FIELD="${YUK1358_LOCK_TOKEN_FIELD:-}" \
  YUK1358_ORIGINAL4_IDS="${YUK1358_ORIGINAL4_IDS:-}" YUK1358_RELEASE_RECORD="${YUK1358_RELEASE_RECORD:-}" \
  YUK1358_PG_IMAGE_ID="${YUK1358_PG_IMAGE_ID:-}" \
  /Users/yuqi/.local/share/mise/installs/node/24.19.0/bin/node .cache/yuk1358-notes-built-acceptance/driver.mjs "$@"
