import assert from 'node:assert/strict';
import { hash } from './common.mjs';
// Pure byte transformation; preparation must never evaluate this bundle.
export function transformHost(text) {
  const marker='\n// server/index.ts\n',cut=text.lastIndexOf(marker);assert(cut>0);
  const prefix=text.slice(0,cut),tail=text.slice(cut+marker.length);
  assert(/^var \w+ = loadApiEnv\(\);\nwarnFlipOrder\(\);/.test(tail));assert(tail.includes('void (async () => {'));
  function init(path) {
    const escaped=path.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
    const m=prefix.match(new RegExp(`var (init_\\w+) = __esm\\(\\{\\s*"${escaped}"\\(\\)`));assert(m,`missing init ${path}`);return `${m[1]}();`;
  }
  const inits=['src/db/client.ts','src/server/config/hydrate.ts','src/server/subjects/hydrate.ts','src/server/contract-epoch/index.ts','src/capabilities/notes/server/note-list-read.ts','src/capabilities/notes/api/contracts.ts'].map(init).join('\n');
  for(const symbol of ['db','hydrateSubjectRegistryFromDb','hydrateConfigFromDb','transitionContractEpoch','CODE_CONTRACT_EPOCH','loadNoteList','NoteListQuerySchema','buildHonoApp','createFrontdoor','capabilities']) assert(new RegExp(`\\b${symbol}\\b`).test(prefix),`missing ${symbol}`);
  const controller=`
${inits}
module.exports = {
  async initialize() {
    const subjects=await hydrateSubjectRegistryFromDb(db),config=await hydrateConfigFromDb(db);
    return {fetch:await createFrontdoor(buildHonoApp(capabilities),'web/dist'),hydration:{subjects,config}};
  },
  epoch(kind){return transitionContractEpoch(db,kind,CODE_CONTRACT_EPOCH,'yuk1358-notes-acceptance','synthetic isolated phase setup');},
  publicList(input){return loadNoteList(db,NoteListQuerySchema.parse(input));},
  hydrate(){return hydrateSubjectRegistryFromDb(db);},
  sql:db.$client,
  codeEpoch:CODE_CONTRACT_EPOCH,
  close(){return db.$client.end({timeout:3});}
};
`;
  const code=prefix+marker+controller;
  return {code,proof:{original_sha256:hash(text),retained_prefix_sha256:hash(prefix),removed_tail_sha256:hash(tail),controller_sha256:hash(controller),transformed_sha256:hash(code),same_emitted_graph:true,
    scope:'exact retained server bundle prefix, canonical Hono capabilities/frontdoor, untouched dist/start generated resolver and server entry; only entry tail replaced',
    omitted_calls:['loadApiEnv','warnFlipOrder','resolveApiPort','initializeLaminarTracing','startConfigRefresh','registerToolsBeforeServe','recoverToolOperationsBeforeServe','injectAdminConfigFactsBeforeServe','injectAdminConfigWriterBeforeServe','startListenLoop','startInProcessWorker','installApiShutdown','canonical serve'],
    retained_setup:['single subject hydration','single config hydration','canonical DB client/auth/epoch','canonical frontdoor serving'],
    limitation:'isolated bootstrap acceptance is not canonical full boot, worker, subscriptions, provider or deployment proof'}};
}
