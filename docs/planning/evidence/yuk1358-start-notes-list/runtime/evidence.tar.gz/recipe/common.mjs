import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, realpathSync, statSync } from 'node:fs';
export const ROOT='/Volumes/YukovalSBak/yukoval-projects/tlp-yuk1352-start-frontdoor';
export const BRANCH='feat/yuk-1358-start-notes-list';
export const PREPARED_HEAD='aa8dd241ddb365969e6d3fb27cf9206d78d54236';
export const PREPARED_SOURCE_HEAD='c236a7160343f7f9a6277ec8c59b70e104ebf267';
export const OPS=['getStartNoteList'];
export const hash=x=>createHash('sha256').update(x).digest('hex');
export const stable=x=>Array.isArray(x)?x.map(stable):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,stable(x[k])])):x;
export const digest=x=>hash(JSON.stringify(stable(x)));
export function parseMap(text) {
  const out={},ids=new Set();
  for(const m of text.matchAll(/"([a-f0-9]{64})"\s*:\s*\{\s*functionName:\s*"([A-Za-z0-9_]+)_createServerFn_handler"/g)) {
    assert(!Object.hasOwn(out,m[2])&&!ids.has(m[1]),'duplicate resolver'); out[m[2]]=m[1];ids.add(m[1]);
  }
  for(const op of OPS) assert(out[op],`missing generated resolver ${op}`);
  return out;
}
export function checkLock(c) {
  assert.equal(c.authorized,'1'); assert(c.owner&&c.token&&c.record&&c.recordHash,'actual parent mutex required');
  assert(c.record.startsWith('/')&&realpathSync(c.record)===c.record&&c.record.includes('/deployment.lock/'));
  assert(statSync(c.record).isFile());const bytes=readFileSync(c.record);assert.equal(hash(bytes),c.recordHash);
  const value=JSON.parse(bytes),field=path=>path.split('.').reduce((v,k)=>v?.[k],value);
  assert.equal(field(c.ownerField??'owner'),c.owner);assert(field(c.tokenField??'token')===c.token,'lock token mismatch');
  assert.equal(process.umask()&0o077,0o077,'runtime requires umask 077');
  return {record:c.record,sha256:c.recordHash,owner:c.owner};
}
export function assertReadOnly(a,b) {
  for(const k of ['schemas','relations','columns','constraints','tables','sequences','boss','migrations']) assert.deepEqual(b[k],a[k],`window changed ${k}`);
  assert.equal(b.boss,false);
}
export function fieldCensus(actual,expected,path='$') {
  if(expected===null||typeof expected!=='object'){assert.deepEqual(actual,expected,path);return;}
  assert(actual!==null&&typeof actual==='object',path);
  assert.equal(Array.isArray(actual),Array.isArray(expected),path);
  assert.deepEqual(Object.keys(actual).sort(),Object.keys(expected).sort(),`${path} exact own-key census`);
  for(const k of Object.keys(expected)) fieldCensus(actual[k],expected[k],`${path}.${k}`);
}
export function assertNoSecrets(bytes,secrets) {
  for(const secret of secrets.filter(Boolean)) {
    assert(!bytes.includes(secret),'secret in public packaging');
    assert(!bytes.includes(Buffer.from(secret).toString('base64')),'encoded secret in public packaging');
    assert(!bytes.includes(encodeURIComponent(secret)),'escaped secret in public packaging');
  }
  assert(!/postgres(?:ql)?:\/\/[^\s"']+@/i.test(bytes),'database URL in public packaging');
  assert(!/"(?:x-internal-token|authorization|password|admin_url|app_url|token)"\s*:/i.test(bytes),'secret field in public packaging');
}

export function publicEvidenceName(name) {
  if(name==='wire.jsonl') return true;
  if(!name.endsWith('.json')) return false;
  return /^(?:egress-denied|rpc-.+|read-.+|reject-.+|epoch-.+|browser-.+|parent-verdict|compare-.+|.+-before|.+-after|.+-no-write|seed-baseline|seed|cleanup|host-.+-proof|failure-.+|serve-ready|serve-stopped|dump-receipt|migrator-receipt|shared-before|shared-after)\.json$/.test(name);
}
