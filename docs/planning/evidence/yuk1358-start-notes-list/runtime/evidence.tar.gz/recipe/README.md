# Native Start /notes LIST parent acceptance at c236

Prepared OFFLINE only for `/Volumes/YukovalSBak/yukoval-projects/tlp-yuk1352-start-frontdoor`, branch `feat/yuk-1358-start-notes-list`, exact `c236a7160343f7f9a6277ec8c59b70e104ebf267`. Owned files and all outputs are restricted to this new ignored `.cache/yuk1358-notes-built-acceptance/`. No old recipe, product, tracked document, PLAN, source, artifact, git ref, shared output or lock is modified. No install/build, PostgreSQL/Docker/Testcontainers, listener, worker, provider, browser or network operation ran during preparation. No children were created. R1 is concurrently read-only and parent-owned. Parent's already executed 18 DB + 50 unit are supplied context, not reruns or built/browser acceptance by this preparer.

`preparation-manifest.json` records actual pure commands/logs, exact statuses and owned hashes. `seal.json` freezes tracked non-document source bytes, all 893 emitted files against `.cache/yuk1358-notes-list/artifacts-sha256.txt`, the source manifest, installed Start transport/Seroval modules, function map, transform proof and helper files. Author compile/check commands and log manifest are hashed as existing evidence. The original author log bytes are verified against their manifest and sealed read-only; no compile command was rerun here. `offline-checks.json` preserves the first exact-HEAD seal failure; `final-offline-checks.json` contains the final pure checks and seal/verify. Exact source/artifact/helper drift stops future phases. Do not rebuild or reseal to bypass drift. Runtime, database, browser, production boot and deployment are explicitly UNRUN by this preparer.

## Pure preparation and verification

These commands only parse/read/hash the frozen build or execute pure helper tests. They never evaluate any product entrypoint. The generated `host-syntax.cjs` is a syntax-check copy inside this owned directory.

```bash
cd /Volumes/YukovalSBak/yukoval-projects/tlp-yuk1352-start-frontdoor
/Users/yuqi/.local/share/mise/installs/node/24.19.0/bin/node --test .cache/yuk1358-notes-built-acceptance/offline.test.mjs
bash .cache/yuk1358-notes-built-acceptance/parent-run.sh verify
```

Preparation ran `offline-check.mjs`, preserved the exact-HEAD failure, then ran `offline-check.mjs final` after adding offline-only documentary-advance handling. All logs are retained. Its manifest is evidence of preparation only. Offline-check refuses reuse of an output label. Use the two commands above and preserve separate logs if the parent needs a new offline verification receipt. Do not rerun `seal`.

The pure tests cover generated-map ambiguity, exact own fields, whole-inventory/sequence changes, the rich fixture corpus, retained host prefix, migration/JSON repairs, secret packaging, LIST versus navigation effects, parent case coverage and observer restoration. The observer simulation uses an in-memory fake underlying response solely to test this helper; it is not browser or product evidence.

## Observed documentary HEAD advance

While preparation ran, the parent committed its DB/unit and handoff documentation as `aa8dd241ddb365969e6d3fb27cf9206d78d54236`. Read-only Git diff confirms only PLAN, .remember and docs/evidence changed since c236. The first strict seal stopped and its failure is retained. The final OFFLINE seal identifies c236 as candidate, checks all current non-document bytes against that candidate and frozen manifests, and records the observed documentary head separately. Runtime `setup/seed/rpc/serve/snapshot` STILL REQUIRE exact c236 HEAD and will fail at aa8dd. No Git checkout/ref operation was performed here. Parent must resolve that execution-revision boundary explicitly, or run the frozen candidate in an authorized exact-c236 context; this kit does not silently accept the newer HEAD. Offline `verify` reports `exact_head_ready:false` at documentary aa8dd and is not runtime readiness.

## Required parent authorization before execution

All remaining commands are prepared, UNRUN instructions for the parent. Before any runtime phase the parent must acquire the real runtime mutex through the established coordinator, own its actual owner/token, and hold it through setup, migration, fixture seed, RPC, browser, cleanup and final shared-runtime comparison. This kit never acquires, rewrites, renews or releases a mutex. No prior token, private env/state, browser token, lock record or private output was read/copied during preparation.

Parent 30-second preflight must resolve exact cwd/branch/HEAD, `verify`, executable Node 24.19.0, local Docker CLI/version/socket, actual mutex record path/owner/token/digest, locally installed pgvector image ID and PGDATA, original four full running container IDs, current-release record and T3 preview capabilities. If the parent has a longer setup operation, preflight remains a bounded readiness check. Do not operate on shared databases. Pin an already installed `sha256:<64hex>` PG/pgvector image declaring `PGDATA=/var/lib/postgresql/data`; `--pull=never` forbids network pulls. Do not use a mutable tag or supply provider/storage/worker credentials.

Parent creates a NEW private env file under this directory using `parent-private.env.example` as its key list, under umask 077. Fill in `YUK1358_PARENT_ACCEPTANCE=1`, actual lock fields and digest, explicit local `DOCKER_HOST=unix://...`, pinned image, `YUK1358_ORIGINAL4_IDS=<four full IDs separated by commas>`, and `YUK1358_RELEASE_RECORD=<absolute real path to current release record>`. The driver checks actual lock JSON owner/token and bytes at every phase, window and serve-owner loop. It checks the original four IDs/images/start times/status/health, full running container set and release-file digest before setup and after owned-container removal. A difference fails cleanup acceptance and the parent retains the mutex for investigation. Parent must also use its established pre/post runtime snapshot procedure and validate the release target if its canonical release identity is more than this file. Neither helper comparison nor source/static evidence substitutes for that check.

Do not echo/print/source private inputs through tools that record shell tracing. Wrapper reads the new ignored env file then clears provider/auth/proxy/telemetry/preload variables before loading Node. Tokens/passwords are generated for this isolated run only, stored privately and excluded from packaging. Parent enters the token privately through the real UI. Never put it in T3 evaluation arguments, transcripts, screenshots, public receipts or a command line.

## Fresh isolated setup, seed and actual built RPC

Execute sequentially with `set -euo pipefail`, and only continue after the preceding command exits zero. Use a new literal run ID for every attempt; never retry a failed phase or seed the same failed run. Do not execute these commands during offline preparation.

```bash
cd /Volumes/YukovalSBak/yukoval-projects/tlp-yuk1352-start-frontdoor
set -euo pipefail
umask 077
export YUK1358_PARENT_ENV_FILE=/Volumes/YukovalSBak/yukoval-projects/tlp-yuk1352-start-frontdoor/.cache/yuk1358-notes-built-acceptance/private-parent.env
NOTES_RUN=notes-parent-20261009-unique01
bash .cache/yuk1358-notes-built-acceptance/parent-run.sh setup "$NOTES_RUN"
bash .cache/yuk1358-notes-built-acceptance/parent-run.sh seed "$NOTES_RUN"
bash .cache/yuk1358-notes-built-acceptance/parent-run.sh rpc "$NOTES_RUN"
```

Setup records shared-before, then creates exactly one owner/run/lock-labelled isolated container with private random DB/passwords, container-owned tmpfs PGDATA, no bind/volume, no Ryuk, no worker, and a loopback-only ephemeral PG publication. It selects an ephemeral loopback HTTP port, which must bind successfully later; an occupied port fails without killing/taking over its listener. The app role has public-table DML and sequence permission, deliberately allowing accidental writes to be detected. It cannot create public relations or another database schema. The independent observer uses the synthetic admin connection.

Setup executes the unchanged frozen `dist/migrate.cjs` through `migrator-runner.cjs`, not an installed generic Drizzle migrator substituted for the real product command. This real built migrator applies the journal, runs builtin-root seed/trait reconciliation, drain/projection readiness checks and contract-epoch readback. Its credentials stay in a scrubbed child environment. Its output stays in private `private-migrator.log`; the public receipt contains exit/signal and log/bundle hashes only. The migrator executes only against the new database. It is not a worker, deployment, restore or shared migration. On failure, preserve the log/digests and clean up only the exact owned container; do not rerun it in place. Inspect the private log without exposing passwords or URLs.

Snapshots compare every journal SQL SHA to actual `drizzle.__drizzle_migrations` rows ordered by insertion `id`. They do not sort non-monotonic journal timestamps. Raw SQL JSON fixture bindings explicitly use `JSON.stringify(... )::jsonb`, because the installed Drizzle postgres-js client disables JSON serializers. Both corrections come from `docs/planning/2026-10-09-yuk1358-start-event-detail-parent.md`, section "Built RPC and browser acceptance at 4f36". No event recipe private artifacts were copied.

The fixture adds two custom selectable subjects backed by general trait bindings, eight rich synthetic knowledge nodes, archived nodes/ancestor cutoff, aliases via existing builtin yuwen registry, inherited custom and builtin children, a seed-only label, missing label and unlabeled notes. It inserts 219 artifacts: 216 active atomic/hub/long notes including 205 boundary-search rows; an archived note, interactive artifact and quiz are excluded. Long nested multilingual TipTap text includes literal `%`, `_`, backslash and HTML text, ambiguity, Unicode, null/false/zero attrs. Versions include zero/17/21, and generation/verification states vary. Every timestamp is deterministic with unique millisecond ordering. Valid builtin roots/traits/event provenance come from the real migrator. Custom fixture setup is raw synthetic SQL, not proof of subject creation writes or business writer acceptance.

The real native Start GET operation is `getStartNoteList`, generated ID `d46ae889bb07e441420d7371ed91168e3c1497e326c9ebdf797836c0494395ff`. `rpc.mjs` imports the exact installed `serverFnFetcher` and Start storage context from the sealed paths and sends a real loopback TCP request. It does not guess wire payloads, substitute a handler or route `/api/*` to imitate server functions. The untouched generated resolver imports the real built handler. Its response is a structured DTO; unlike the prior event GET, do not apply a second `JSON.parse` to a successful result.

RPC matrix has separate whole-database/sequence before/after windows. Auth is checked against absent/wrong tokens before malformed input and epoch. Preparing and ready phases return actual503; epoch setup receipts allow only contract_epoch mutation, outside read windows. Active invalid/non-object, blank subject/query, wrong types and >200 query return actual400. `{}` is a valid unfiltered request. A200-character search returns all205 matches. No filter returns216 full rows unpaginated. Unknown and empty subjects return[]; custom domains, inherited labels, yuwen/wenyan/classical_chinese aliases, trimming and archived ancestor/root exclusion retain exact semantics. Title/body substring matches combine with subject filters, escape percent/underscore/backslash and avoid wildcard decoys. ISO timestamps and every own DTO key/value compare against independent deterministic expected rows, the retained emitted public reader, and actual legacy `/api/notes` TCP responses. `/api/subjects` is explicitly exercised, including both custom subjects and builtin subjects, with general excluded. This validates the preserved HTTP endpoint in RPC phase; actual hook/browser consumption is a separate requirement.

Every snapshot inventories every actual non-system schema/relation/column/constraint, full tables/materialized-view rows, canonical row text, digests, all sequences and journal hashes. It includes synthetic identity and Drizzle tables; no hardcoded table count/allowlist hides unrelated writes. LIST/auth/rejection windows require exact equality. Sequence `last_value` and `is_called` are compared as well as rows. This detects observed final state changes; it does not prove absence of rolled-back transient DML or failed allocation outside the measured window. No seed, epoch change or UI navigation runs within LIST read windows.

## Host transform and acceptance limits

`host-transform.mjs` copies every byte before the emitted `// server/index.ts` marker. Only the canonical entry tail is replaced. The new controller exports DB, publicList, epoch transition and one-shot subject hydration for setup/comparison. It initializes the emitted canonical Hono capability graph/frontdoor and the unchanged `dist/start/server/server.js` entry. It adds no HTTP/RPC route, remapping, fake DTO, business selector, response replacement or alternate writer.

The replacement skips dotenv/port selection/warnings, Laminar, repeating config refresh, tool registration/recovery, admin facts/writer injection, event LISTEN, in-process worker, shutdown hook and canonical listener. Subject/config hydration happens once at isolated host initialization; explicit post-fixture hydration updates only that setup process. The original CJS DB and native ESM DB pools close by their exact handles. Bootstrap omissions are deliberate runtime behavior changes and exclude canonical full boot/provider/worker/subscription acceptance. Domain reader, API route, Start handler/resolver, browser page and transport remain frozen. If execution reveals another needed behavioral transform, stop and report it; do not silently rewrite product behavior to pass.

Driver and migrator guard only admit outgoing TCP to the isolated PG, and driver additionally permits this isolated HTTP origin. TLS, UDP/DNS, external fetch and application background intervals fail. Serve uses bounded timeout polling to check its exact lock and stop request. Any attempted egress is a failed acceptance, even with a zero paid counter. Strict acceptance CSP blocks external fonts/connections and workers; preserve any font/CSP evidence, use fallback fonts, and do not claim production font parity or canonical security/bootstrap parity.

## Parent T3 preview browser recipe

After actual RPC success, start serve in the parent's separate owning terminal under the same mutex.

```bash
bash .cache/yuk1358-notes-built-acceptance/parent-run.sh serve "$NOTES_RUN"
```

Read public `runs/<run>/serve-ready.json` for the dynamic origin. Use T3 `preview_status`, `preview_open` if needed, `preview_navigate`, `preview_snapshot`, focused locators and network/screenshot/recording tools supported by the current catalog. Do not launch Playwright, external browser automation or another browser worker. Install `browser-observer.js` through a supported page-evaluation tool after reaching the exact origin. If evaluation is unavailable, keep fault/observer-dependent cases BLOCKED and use actual T3 evidence for reachable cases. Do not mark a substitute fixture/console simulation as PASS. Observer records all same-origin fetch methods/paths/statuses and actual notes/subjects response bodies, never request headers/storage/token values. It records the search input and its timestamp. Document navigation and requests before installation require separate T3 network evidence. Install again after each new document. Never export headers or screenshot a filled token input.

Fault commands are real page-evaluation expressions, prepared only:

```javascript
window.y1358NotesObserver.arm('hold-before-send', 1)
window.y1358NotesObserver.release()
window.y1358NotesObserver.arm('before-send', 4)
window.y1358NotesObserver.arm('after-response', 1)
window.y1358NotesObserver.arm('wrong-token', 1)
window.y1358NotesObserver.export()
window.y1358NotesObserver.restore()
```

All rules target only the sealed notes GET. A hold delays transport until release. Before-send throws without contacting the server; after-response hides an actual recorded successful response with a transport error; wrong-token changes only this request and produces a real401. No rule constructs Response or modifies DTO/status. These are controlled client transport faults, not demonstrated production faults. React Query's default retries may send four GET attempts before terminal error. Arm four before-send failures, allow the observed retry/backoff window to finish, preserve all attempts and then export. A fault count is a cap, not proof that four attempts occurred. Before clicking the actual retry button, `restore()` MUST restore the underlying real fetch and release/remove every rule. Save that receipt, reinstall a fresh observer without arming it, and only then click `重试`. Do not leave a rule intercepting the recovery request. No fixture manipulation or fabricated500 is accepted as production behavior.

For each case record a distinct snapshot window. Example below, replacing the literal label with one case name per window. Snapshot commands remain parent-only DB execution.

```bash
bash .cache/yuk1358-notes-built-acceptance/parent-run.sh snapshot "$NOTES_RUN" browser-subjects-before
# Parent drives original UI and saves the observer export privately as sanitized JSON.
bash .cache/yuk1358-notes-built-acceptance/parent-run.sh snapshot "$NOTES_RUN" browser-subjects-after
/Users/yuqi/.local/share/mise/installs/node/24.19.0/bin/node .cache/yuk1358-notes-built-acceptance/browser-verdict.mjs list \
  ".cache/yuk1358-notes-built-acceptance/runs/$NOTES_RUN/browser-subjects-before.json" \
  ".cache/yuk1358-notes-built-acceptance/runs/$NOTES_RUN/browser-subjects-after.json" \
  ".cache/yuk1358-notes-built-acceptance/runs/$NOTES_RUN/browser-subjects-observer.json" \
  ".cache/yuk1358-notes-built-acceptance/runs/$NOTES_RUN/browser-subjects-receipt.json"
```

Record the following original UI cases with actual screenshots/snapshots/network receipts and verified windows:

1. `cold-token-gate`: fresh isolated origin deep `/notes`; remove only this origin's saved access state through parent UI before the window. Observe TokenGate before access and separately prove missing-token RPC401. Privately submit run token, observe real auth-check200 and native notes GET. No token screenshots. Capture Start document/assets and first request with T3 network tools; observer installation cannot retroactively capture them. Save a cold-gate snapshot before entering the token and a visible NotesPage after it.
2. `subjects-http-custom`: show original selectable subject tabs and actual `/api/subjects`200 body with Synthetic science and Synthetic empty. Static builtin first-frame fallback is insufficient. Click science, observe notes GET input and only custom note. Click yuwen and math, compare rows. No subjects fake response or replacement provider. Inspect all observed shell fetches/methods during this LIST window.
3. `search-debounce250`: start settled, record search input events and requests after fast typing `NEEDLE`; verify no request per intermediate keystroke and final request occurs at least250ms after the last input. Observe language/custom/math title hits; select yuwen and search `深层正文` for inherited body hit, math plus that term for no match. Decode serialized request payload through the exact installed serializer if needed, retaining raw payload/digest; do not infer query timing from arbitrary wall-clock waits. Background shell requests and React Query retries are distinct from debounced notes GET. Reused cached query keys may issue no request; use a fresh uncached term, or fresh document + observer, and keep actual request timing.
4. `search-clear`: click actual `清除搜索`, wait observed debounce and restored unfiltered216 counter/results. Whitespace input trims to omission in UI client; do not claim UI blank400, which belongs to raw RPC contract. Search200 boundary and >200400 are RPC cases; optionally observe actual UI over200 error, never change max.
5. `empty-search`: use fresh no-match string and show `没有找到匹配的笔记` and existing guidance, then clear. `empty-subject`: clear search, select Synthetic empty and show `还没有匹配的笔记`, then return all. Distinguish loading from []200.
6. `loading`: on a settled page arm hold-before-send once and enter a fresh uncached term. Observe `取笔记…`, pending notes GET and no empty/error state before release. Release and observe real response/appropriate result. Export and restore the observer after the hold ends. No synthetic data response.
7. `error-restored-retry`: on a fresh uncached query arm before-send up to four times, observe actual controlled GET failure attempts and original `笔记加载失败。` plus `重试`. Save first window, export, restore real fetch, and record that restoration. Install clean observer; take a new before snapshot; click actual retry. Require successful real native GET plus recovered UI and no writes across both failure and recovery windows. A timeout or still-pending React Query retry is not terminal error acceptance. Parent case evidence includes both windows; `window` field below points at the recovery window and separate failure receipt is hashed evidence.
8. `refresh`: after restoring transport, deep document reload `/notes` with token retained, observe real native GET and original page; cached/refresh timing must be captured with T3 document/network tools and new observer. No POST or replay. The original NotesPage has retry and document refresh, not a newly invented refresh button.
9. `wrong-token-regate`: with clean observer arm one wrong-token notes GET on a fresh query. Record actual401 and real gate clearing access, then restore underlying fetch before privately re-entering the run token. Require real auth-check200/native GET recovery, and LIST table/sequence equality. Use separate observers/windows for denial and recovery and archive both.
10. `note-detail-navigation`: start a separate navigation window, click actual language note card and verify URL `/notes/y1358n_language`, retained detail page and long rich text. Restore observer before leaving and reinstall after arrival; use T3 document/network evidence for transition. Do not edit/save, click editor, trigger AI, refine/verify, dwell intentionally or grant worker/provider credentials. Detail/presence may independently POST or write; record all actual methods and before/after differences using `browser-verdict.mjs navigation`. Such effects do not belong to LIST no-write acceptance and cannot be silently ignored or counted as Start detail migration. If the page cannot render or guard blocks an expected detail timer, report that limitation.
11. `knowledge-navigation`: in another separate window click original `从知识点浏览`, verify `/knowledge` retained route and actual content, then a synthetic knowledge row if reachable. Record independent HTTP/document methods and effects with navigation verdict. No knowledge edits. Do not claim these retained routes are native Start readers or accepted writes. If navigation itself has unexpected effects, preserve evidence and parent verdict explains them separately.

The two navigation cases have their own before/after snapshots and effect reports. Never navigate to them between a LIST before/after pair. LIST requires zero observed mutating methods and equality of all tables/sequences. Navigation preserves effects without calling them a LIST failure or accepted write. Reinstalling observers misses transit requests, so T3 network/document evidence must fill that coverage gap. Screenshots alone cannot establish transport/DB parity. No reachable403/500 is invented; record no real producer as unreachable, and controlled transport failure separately.

## Parent verdict, failure handling, cleanup and packaging

Before ending runtime stop only the exact serve terminal/handle with Ctrl-C, or let cleanup request `stop-serve.request` and wait for that owner to write `serve-stopped.json`. No saved-PID kills, global prune, volume deletion, queue reset, shared app/worker stop or provider call. Source/artifact drift is tolerated only by exact-owned cleanup, never for acceptance. Container image, full ID, run/owner/lock labels, tmpfs and loopback binding must still match. If Docker create's outcome was lost, preserve setup-intent and inspect exact labels under parent ownership before recovering. Do not guess resource names or rerun create. If no owned resource exists, parent performs only shared-state/lock verification; do not claim cleanup succeeded automatically.

```bash
bash .cache/yuk1358-notes-built-acceptance/parent-run.sh cleanup "$NOTES_RUN"
```

Cleanup removes only this labelled isolated container and records absence, then rechecks original four, whole running set and current release against shared-before. On any failed phase preserve failure/intent/wire/before/after evidence, stop exact owned handle, clean only exact owned resources, validate shared state, and keep failed attempt archived. Use a new run only after parent adjudication. No repeated phase may erase a failure. Private synthetic dump is optional only at parent's explicit request before cleanup, using the existing `dump` phase; it stays excluded from packaging.

Parent writes sanitized `runs/<run>/browser-parent-verdict.json` with exactly the12 case IDs above. Each case has `id`, `accepted:true`, `observed:true`, explanatory `note`, nonempty `evidence` containing same-directory basenames, and `window:{before:'...json',after:'...json',observer:'...json'}` naming actual snapshot/observer files. Evidence must include all three window files plus visible/T3 records and no-write/navigation receipt. `error-restored-retry` also needs `real_transport_restored_before_retry:true` plus the actual restoration record and both failure/recovery evidence. Parent may not fill accepted/observed from this recipe. BLOCKED/FAIL/UNRUN means retain a manual incomplete verdict and do not run a pass aggregator. This helper validates case completeness and reruns all12 bounded window assertions; parent still owns truth of visible/tool observations.

```bash
/Users/yuqi/.local/share/mise/installs/node/24.19.0/bin/node .cache/yuk1358-notes-built-acceptance/parent-verdict.mjs \
  ".cache/yuk1358-notes-built-acceptance/runs/$NOTES_RUN"
bash .cache/yuk1358-notes-built-acceptance/parent-run.sh package "$NOTES_RUN"
```

Aggregator requires actual rpc-pass/summary, real built migrator exit0, exact cleanup/shared equality, all observed cases and zero recorded egress denial. It never claims canonical boot, deployment, provider quality, detail writes or full Notes family completion. Before publication parent reviews raw evidence and failures, serializer/source/build hashes, no-write inventory/sequence windows, T3 navigation gaps, screenshots, and absence of provider calls. A helper pass is not parent acceptance without those observed artifacts.

Packaging allowlists public JSON/wire files, scans real synthetic credentials plus mutex token and encoded variants, writes file hashes, and excludes private env/state/browser-token/migrator-log/SQL dump/host code/arbitrary files. Images/videos and T3 export files need parent manual redaction/review. `preparation-manifest.json` hashes only owned preparation files and frozen public inputs; no private records. Parent can archive the verified original author compile/check logs together with their digests. Mutex release happens only through parent/coordinator exact owner/token validation AFTER cleanup and established pre/post original4/release snapshot validation. Keep a sanitized release receipt/digest. This kit neither releases the mutex nor equates mutex removal to verified cleanup. No repository/PLAN/Linear/PR action belongs to this test-only task.

Prepared commands and all runtime/browser cases above are UNRUN by the preparer. Parent runs the real artifact and supplies the final observed verdict.
