import assert from 'node:assert/strict';
import { hash } from './common.mjs';
// Pure byte transformation. No import/evaluation of emitted code in preparation.
export function transformHost(text) {
  const marker = '\n// server/index.ts\n';
  const cut = text.lastIndexOf(marker); assert(cut > 0);
  const prefix = text.slice(0, cut), tail = text.slice(cut + marker.length);
  assert(/^var \w+ = loadApiEnv\(\);\nwarnFlipOrder\(\);/.test(tail));
  assert(tail.includes('void (async () => {'));
  function init(path) {
    const escaped = path.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const m = prefix.match(new RegExp(`var (init_\\w+) = __esm\\(\\{\\s*"${escaped}"\\(\\)`));
    assert(m, `missing emitted initializer ${path}`); return `${m[1]}();`;
  }
  const inits = ['src/db/client.ts','src/server/config/hydrate.ts','src/server/subjects/hydrate.ts',
    'src/server/contract-epoch/index.ts','src/capabilities/agency/server/note-board-read.ts'].map(init).join('\n');
  for (const symbol of ['db','hydrateSubjectRegistryFromDb','hydrateConfigFromDb','transitionContractEpoch',
      'CODE_CONTRACT_EPOCH','loadAgentNoteBoard','buildHonoApp','createFrontdoor','capabilities'])
    assert(new RegExp(`\\b${symbol}\\b`).test(prefix), `missing symbol ${symbol}`);
  const controller = `
${inits}
module.exports = {
  async initialize() {
    const subjects = await hydrateSubjectRegistryFromDb(db);
    const config = await hydrateConfigFromDb(db);
    return { fetch: await createFrontdoor(buildHonoApp(capabilities), 'web/dist'), hydration: { subjects, config } };
  },
  epoch(kind) { return transitionContractEpoch(db, kind, CODE_CONTRACT_EPOCH, 'yuk1358-agent-notes-acceptance', 'isolated synthetic phase boundary'); },
  publicBoard(input, now) { return loadAgentNoteBoard(db, input, now); },
  codeEpoch: CODE_CONTRACT_EPOCH,
  close() { return db.$client.end({ timeout: 3 }); }
};
`;
  const code = prefix + marker + controller;
  return { code, proof: { original_sha256: hash(text), retained_prefix_sha256: hash(prefix),
    removed_tail_sha256: hash(tail), controller_sha256: hash(controller), transformed_sha256: hash(code),
    same_emitted_graph: true, scope: 'retained emitted Hono/frontdoor/domain plus exact dist/start; isolated initialization replaces canonical entry',
    omitted_calls: ['loadApiEnv','warnFlipOrder','initializeLaminarTracing','startConfigRefresh','registerToolsBeforeServe',
      'recoverToolOperationsBeforeServe','injectAdminConfigFactsBeforeServe','injectAdminConfigWriterBeforeServe','startListenLoop','startInProcessWorker','canonical serve'] } };
}
