# YUK-1358 agent-note acceptance preparation

This is an OFFLINE recipe, not runtime evidence. Nothing here has started Postgres, Docker, a listener, a browser, a provider or a worker. The parent's reported three-file/14-case actual DB pass is separate evidence supplied by the parent, not executed or verified by this preparer. Parent owns the tracked report, PR and runtime mutex. This preparation changes only this ignored directory and `/tmp/yuk1358-agent-notes-prep`.

Workspace `/Volumes/YukovalSBak/yukoval-projects/tlp-yuk1352-start-frontdoor`, branch `feat/yuk-1358-start-agent-notes`, candidate `c10e1188528a04c789d6aff1dac2eafee4db6cba`. Author report is `docs/planning/2026-10-09-yuk1358-start-agent-notes-implementation.md`; manifest is `docs/planning/evidence/yuk1358-start-agent-notes/hashes.json`. These tracked files are read-only inputs. The author report still describes its earlier evidence stage; parent must report later DB/RPC/browser evidence separately.

## Pinned bytes and scope

`seal.json` records every tracked non-document file, every `dist/start` and `web/dist` file, `dist/server.cjs`, installed Start fetcher/storage/Seroval implementation files, the resolver map, recipe files and the transformed-host proof. It crosschecks every source/artifact entry in the author manifest. The parent advanced to `8bfc4d20354679b6e428b38359385bcb0cdf0cab` during preparation. Its only non-document changes against the candidate are the expected Start handoff count from11 to12 in `AdminControls.start.unit.test.tsx` and `AdminPages.start.unit.test.tsx`; their diff was inspected. Executable source and all author-owned source/artifact hashes remain pinned to the candidate. The broader non-document map includes these parent test-only repairs at that source baseline. It permits a later descendant commit containing only docs/evidence/PLAN/remember/README changes while requiring identical product bytes, dependencies and build artifacts. Dirty or untracked product files are refused. It never rebuilds or installs. If product/build/recipe bytes change, this recipe must be prepared again with separate evidence; never delete the old seal/run to hide drift.

Author source manifest `bc707b29a7d70275e1f5dd376c3713cad3ebe9c232858a66c21549e2e980f6ba`, 19 files. Author artifact manifest `96604d5ba1c43a0c2d5e248daccb360132118e015966e2763b58ad1314c1b6dd`, 878 files. This controller's broader product map and its runtime-artifact map have their own digests in `seal.json`; they are different denominators.

The current actual resolver ID is `1fad3216afa22f42733756f3cf8bee84d0a0478c29b8de170a59f87718a84ca4`. Each runtime phase resolves and checks the emitted resolver bytes again. No fixture name supplies an ID. `rpc.mjs` calls the installed `serverFnFetcher`, its installed Seroval path and real HTTP fetch to a TCP loopback listener. That listener executes the exact built Start server functions. There is no test DTO fulfillment or mocked selector in the claimed RPC.

`host-transform.mjs` retains the emitted `dist/server.cjs` prefix byte-for-byte. It replaces only the canonical `server/index.ts` entry tail with an explicit isolated host. The emitted Hono, capability routes, frontdoor, public loader and epoch transition remain real. It hydrates subject/config reads once, then serves the exact `dist/start` output. It omits env-file loading, tracing, config refresh timers, tool registration/recovery, config facts/writer injection, subscription/listen loops, worker and canonical listener startup. These omissions are recorded and hashed. This is isolated emitted-host acceptance; it does not prove the normal canonical bootstrap, deployment or whole migration. The older config-write scenarios, refresh failure proof and writer injection are not carried forward. Source imports are used only for synthetic fixture insertion, not RPC/HTTP/public parity. Both emitted CJS and Start ESM DB pools are closed.

The source-based `server/start/acceptance-server.ts` is an alternative parent-owned host only. If parent chooses it, call the result hybrid source-Hono plus built-Start evidence and prepare a separate scope/hash record. This controller does not launch that alternative.

## Parent pre-flight and private settings

Every command below is MANUAL and parent-only. None has run in this preparation. Parent first obtains the shared runtime mutex through its established owner process. No command below acquires, steals, replaces or releases it. Parent must confirm the former owner has released it, record the original shared services/release identity, and pass the current owner/token/record/hash. Do not manufacture an example lock to pass the check. A changed lock record stops the controller; it cannot resume against another owner's lock.

Under `umask 077`, copy `parent-private.env.example` to `private-parent.env` in this directory and fill privately. Supply only the actual mutex fields, explicit local Docker unix socket and an already installed Postgres/pgvector image ID. Never source the main app `.env` or export provider credentials. Do not print/token-screenshot any private file, use shell tracing, or put a token on a CLI argument. `private-state.json`, `postgres.env`, `synthetic-app.env`, `browser-token.txt` and the parent's env file are ignored private run inputs. Runtime creation respects the parent umask, with no hardcoded permission bits. Keep private env content out of tracked evidence.

Before setup, check executable/version/auth/target resolution within 30 seconds using the already running local engine. Do not run `orbctl`, Docker Compose, Testcontainers, image pulls or engine recovery commands. Confirm Node 24.19.0, installed `tsx`, Docker executable/current unix socket, pinned local PG/pgvector image, free `127.0.0.1:18954` and the actual mutex. Do not kill a port occupant. This preparation performs none of those runtime checks. `setup` itself records Docker version and verifies the pinned image locally before creating anything.

Controller sanitizes its inherited environment before application imports, retaining only PATH/TMPDIR/LANG/LC_ALL and the explicit Docker socket. Then it sets synthetic DB/token/port and `RW_WORKER=0`. Node outbound socket/fetch guards allow only this run's PG port and `127.0.0.1:18954` HTTP, block other TCP, unix sockets, TLS/provider connections and UDP, and reject background intervals. It does not install a host firewall or change global networking. The pinned vanilla PG container has no app/worker/provider credentials and runs only PG; no provider extension or network function may be installed or invoked.

Browser network is a separate process. Before browser acceptance, parent must enforce an automation/network allowlist admitting only `http://127.0.0.1:18954` and ordinary browser-internal URLs. Block external requests, DNS/prefetch and telemetry rather than relying solely on an observer. `browser-faults.js` blocks external JavaScript fetch, but is not a complete browser egress firewall. If the selected browser tool cannot enforce the required egress boundary, browser acceptance remains blocked. Do not weaken that boundary or claim it was covered by the Node guard.

## Manual parent commands

Use a fresh run name. Execute commands individually so the parent can inspect receipts between phases. All CLI phases fail nonzero; `set -e` preserves that failure. Never join steps with an unconditional continuation or pipe without `pipefail`.

```bash
set -euo pipefail
umask 077
cd /Volumes/YukovalSBak/yukoval-projects/tlp-yuk1352-start-frontdoor
YUK1358_RECIPE="$PWD/.cache/yuk1358-agent-notes-built-acceptance"
export YUK1358_PARENT_ENV_FILE="$YUK1358_RECIPE/private-parent.env"
YUK1358_RUN='parent-agent-notes-20261009-a'
# Static pin verification is safe before acquiring a runtime mutex.
bash "$YUK1358_RECIPE/parent-run.sh" verify
# Parent acquires its mutex separately before continuing.
bash "$YUK1358_RECIPE/parent-run.sh" setup "$YUK1358_RUN"
bash "$YUK1358_RECIPE/parent-run.sh" seed "$YUK1358_RUN"
bash "$YUK1358_RECIPE/parent-run.sh" rpc "$YUK1358_RUN"
```

`setup` creates a new labeled PG container with one ephemeral host PG port bound to `127.0.0.1`, a unique database, identity schema and private credentials. It runs migrations only there. It uses `pg_isready -h 127.0.0.1` inside that container, then establishes a real host TCP DB connection. A temporary bootstrap Unix socket is never readiness evidence. The application role has SELECT/INSERT/UPDATE/DELETE on only that isolated database's public tables and USAGE/SELECT/UPDATE on its sequences. UPDATE is intentionally available to the emitted host where required. It has no schema-create grant, main database grants or main credentials. Broad isolated DML privilege means the no-write gate observes behavior rather than merely proving writes were denied.

`seed` inserts a rich synthetic transaction directly using Drizzle. It creates 205 eligible notes plus expired, exact-boundary, wrong-action and wrong-subject controls; three knowledge rows; active/null/future/draft/blank question variants; active/done goals; a completed review session and synthetic user events. Long multilingual text, nested provenance, zero confidence, known/unknown signal/ref kinds, refs to missing entities, far-future expiry and absent optional fields remain intact. Top 20 notes are fresh, the next 15 yesterday and earlier rows carry distinct primary reference groups, giving the full page three day bands. It reuses workbench fixture structure from `src/capabilities/shell/api/workbench-summary.db.test.ts`. These are synthetic historic records, not scoring operations. It performs no AI call or config mutation. It advances the real emitted epoch state machine through preparing/ready/active, and records the canonical code epoch.

`rpc` binds the loopback listener only for that phase. It brackets auth denials and read/error cases with snapshots. Missing/wrong token401 use malformed input while fenced; valid-token503 in preparing and ready precede malformed/domain validation. Explicit epoch transitions are classified separately as setup writes to `public.contract_epoch`. Active requests cover `{}` default20, 20, 50, 200, string50, invalid0/-1/>200/fraction/text and malformed input400. Undefined input is invalid because the canonical schema requires an object. Real HTTP and emitted public-loader DTOs match actual built RPC DTOs, including enriched refs, unknown nested fields, ISO dates and fallback source keys. No expiry can change across the actual parity interval: boundary is already past, 2000 is past, 2099 is future. Actual clocks are saved; no global Date mock is installed. The exact boundary receives a separate genuine emitted-public-loader comparison at seed time and seed-minus1ms; this is not claimed as RPC clock injection.

Every snapshot hashes all rows of each of the migration-derived exact 88 public tables plus other non-system table/materialized rows, inventories all non-system relations including indexes/views/sequences, stores column/constraint/view/index definitions and every sequence value/is_called. Reads require identical table counts/digests, relations, columns, constraints, sequences and absent pg-boss schema. It fails closed if the table census differs. There is no allowlist of changed tables inside the read window. Sequence equality is required for reads; setup sequence allocation remains outside that window. `wire.jsonl` records actual sanitized RPC/HTTP bytes, response hashes, clocks and header names, with no request authorization values. Keep all raw run receipts ignored/private until the parent reviews them for export.

In a second terminal, with the same private env and parent mutex still owned:

```bash
set -euo pipefail
umask 077
cd /Volumes/YukovalSBak/yukoval-projects/tlp-yuk1352-start-frontdoor
export YUK1358_PARENT_ENV_FILE="$PWD/.cache/yuk1358-agent-notes-built-acceptance/private-parent.env"
bash .cache/yuk1358-agent-notes-built-acceptance/parent-run.sh serve parent-agent-notes-20261009-a
```

This requires an actual `rpc-pass.json`, writes serve PID/origin/hash receipts and stops after 45 minutes or an exact owned stop request. No other port or PID is reused. Parent reads `serve-ready.json` before opening the browser; existence of a started marker alone is not readiness.

Take snapshot markers manually in the first terminal, replacing names for each bounded step:

```bash
bash "$YUK1358_RECIPE/parent-run.sh" snapshot "$YUK1358_RUN" browser-notes-before
# Parent performs ONLY the bounded note refresh/filter/read-mark step.
bash "$YUK1358_RECIPE/parent-run.sh" snapshot "$YUK1358_RUN" browser-notes-after
bash "$YUK1358_RECIPE/parent-run.sh" compare "$YUK1358_RUN" browser-notes-before browser-notes-after
```

For broader initial Today, reference navigation or legacy SPA handoff, save before/after markers under distinct names and classify every difference. Do not automatically call `compare` expecting zero writes across unrelated navigation. Establish and record any legitimate retained-page initialization first; then isolate note-only windows. Parent must not relabel a changed window as a note-read PASS.

## Manual actual browser acceptance

Use T3 `preview_status`, then `preview_open` if needed, then snapshot-provided locators and focused interactions. Inspect/retry actionable errors. Use a fallback browser only if T3 tools are absent or `preview_open` explicitly says unavailable/unsupported, recording that result. Never bypass an initially closed preview. This preparation starts no browser and tests no UI.

1. Attach the isolated origin only. Enforce browser egress policy. Enter the generated `browser-token.txt` through the real token gate privately, without logging its value. Start with a clean acceptance-origin localStorage or preserve it under a separate private receipt; never clear storage on a main origin. Use the actual `/today` and `/agent-notes` documents, not test RPC adapters.
2. Record served document and built asset hashes/paths, Start ownership, actual RPC ID/method/query/header-name presence and clock. Today must show `cold_start.is_empty=false` from real workbench data, fetch note limit20, and render the board. Full page must fetch50 and show 50 active observations. Neither note consumer may fetch `/api/agents/notes`. Other Today/RootShell HTTP reads are separate, expected retained consumers. Do not equate the number of grouped visible cards with the raw 20/50 rows.
3. Expand Today, inspect known/unknown signal copy, open grouped runs/evidence, long original text and far-future/no-expiry display. Excluded note IDs must not surface. On full page filter a known chip and the unknown `future_signal` chip, which uses the fallback label "其他信号"; another unknown chip may share that label, so use the snapshot occurrence and recorded count. Restore All. Verify repeated signals with the same primary ref group without losing real run IDs. Verify Today/yesterday/earlier bands from the seeded groups.
4. Expand refs and check resolved/open/unknown knowledge and active/draft/missing/blank question labels. Follow a resolvable reference, record the actual target, then return. Unknown refs must remain safe and preserve available evidence. Reference navigation may read/initialize other retained resources; keep it outside a note-only no-write claim. Do not answer, score, generate, accept a proposal or invoke Copilot.
5. With isolated-origin local reads initially empty, mark Today rows read and capture only `loom-annotes-read` and `loom-annotes-open`, omitting `loom_internal_token`. Navigate to the full page and verify the shared fresh IDs are read. Mark any remaining displayed unread notes read if offered; return to Today and reload both pages. Assert stored IDs are retained and expansion restores. Synchronization is through the shared keys on route mount; do not claim cross-tab live synchronization, which this hook does not implement. Bracket these local-only actions separately and require unchanged DB snapshots.
6. Install `browser-faults.js` only in this isolated page after genuine data loads. Use `y1358AgentNoteFaults.arm('<sealed ID>','transport-error',4)` or enough bounded failures for the observed automatic-retry policy. Trigger a real refresh by navigating away/back while keeping the observer in the same document; actual settled cached data must not be mistaken for a new request. Record failed requests and error UI. Clear rules, click the real Retry and require a successful actual serialized200/50 or200/20. Failure is deliberately injected at transport, recovery uses the real server. If a document reload removes the observer, reinstall before the refresh. No fake response may substitute for the retry result.
7. Arm one `wrong-token` request to the same sealed ID and trigger a genuine read. The actual server must return401, the client must clear/regate authorization, and the real token dialog must appear. Clear the rule, privately re-enter the correct generated token and require an actual successful RPC. Record status, dialog and recovered rows without token values. Bracket denial/retry note reads with snapshots; do not attribute unrelated auth/navigation effects to the selector.
8. Start on a retained legacy SPA route such as `/knowledge`; record SPA assets and document identity. Use its UI navigation to `/agent-notes`, requiring the existing full-document handoff into Start and a real50-row RPC. Deep-refresh `/agent-notes`, follow its Today backlink, and verify Today again calls20 without overwriting the full-page50 cache. Save separate legacy/Today navigation markers and classify any retained-resource changes. Do not use `/practice` as a supposedly write-free starting page.

Save screenshots, sanitized network observations, actual clocks, local-read-key snapshots, page/asset identity and each marker verdict under this run. `y1358AgentNoteFaults.export()` excludes the token key. Browser screenshots of the token dialog must hide the value. `rpc-pass.json` never implies browser PASS; parent writes a separate acceptance result after checking real evidence. A request observer alone is not page acceptance.

## Cleanup and failed outcomes

Only after parent has saved needed synthetic data/evidence:

```bash
bash "$YUK1358_RECIPE/parent-run.sh" snapshot "$YUK1358_RUN" final-before-cleanup
bash "$YUK1358_RECIPE/parent-run.sh" cleanup "$YUK1358_RUN"
# Parent separately verifies original services/release identity and releases its own mutex.
```

Cleanup checks the current lock and exact saved container ID, image, two ownership labels and loopback port binding. It asks only the matching serve process to close its owned listener via the run's stop-request file, waits for its reciprocal stopped receipt, and removes only that labeled container. It never kills a saved PID, a port occupant, a whole compose project, a main container or the runtime mutex. No source/build drift can prevent exact-owned cleanup, but lock/identity drift does. It preserves run files and failure receipts.

If setup fails before `owned-container.json` is written, creation outcome is unknown. Parent must inspect only the unique `setup-intent.json` owner/lock labels on its selected local engine, resolve identity privately, and perform exact-owned cleanup; never retry create blindly or reset that run. If a serve process died without its stopped receipt, automated cleanup refuses; parent verifies process/handle ownership and records an explicit recovery result. A reused PID is never authorization to kill. Failed seed/RPC phases are not replayed against their existing run. Clean only proven owned resources, then prepare a fresh run; retain the failure and its unknown state.

## Offline validation and limits

`offline.test.mjs` checks pure fixture structure, strict snapshot equality behavior, the actual resolver and retained host bytes without importing any emitted application code. `node --check` checks the controller, modules, optional browser helper and transformed emitted host syntax. `seal`/`verify` only read Git/files and hash bytes. `host-syntax-proof.json` and `offline-checks.json` record exact commands and results. These checks prove preparation consistency, not that migrations, hydration, network guards, the listener, auth, serialization, selector, no-write comparisons or UI work at runtime. Parent must execute and inspect those phases under its mutex. No deployment, full migration, provider quality, main DB recovery or exact-head CI claim follows from this recipe.

Parent correction: initial setup failed because the offline recipe guessed90 public tables. Journal SQL yields95 creates minus7 dropped names =88; parent now asserts all88 exact table names, plus full non-system relation/row/sequence inventory. Initial failed run/recipe are preserved. Browser-only serving adds CSP self-only resource/connect restrictions and disables DNS prefetch; this is explicit acceptance instrumentation, not shipped headers or a browser-engine firewall claim. It admits inline styles/scripts required by shipped assets and data/blob local assets. No external navigation is part of the acceptance.
