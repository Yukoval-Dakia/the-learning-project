import assert from 'node:assert/strict';
export const LONG_TEXT = '# 合成观察原件 / Synthetic observation / 観察\n条件缺失 ≠ 已证实错误。α β🙂\n- 保留未知、失败与不同解释。\n'.repeat(180);
export function makeFixture(now) {
  assert(now instanceof Date && Number.isFinite(+now));
  const provenance = { source: { run_id: 'synthetic_original_run', event_id: 'synthetic_original_event', excerpts: [LONG_TEXT] }, alternatives: [null, false, { confidence: 0, reason: '尚无判定 / unresolved' }] };
  const refs = [
    { kind: 'knowledge', id: 'y1358n_k_resolved', provenance },
    ...['open','draft_only','missing'].map(k => ({ kind: 'knowledge', id: `y1358n_k_${k}` })),
    ...['active','null','future','draft','blank','missing'].map(k => ({ kind: 'question', id: `y1358n_q_${k}` })),
    { kind: 'event', id: 'y1358n_original_event' }, { kind: 'note', id: 'y1358n_missing_note' },
    { kind: 'artifact', id: 'y1358n_missing_artifact' },
    { kind: 'future_ref', id: 'y1358n_unknown_α', extra: { nested: [null, '原件', { confidence: 0 }] } },
  ];
  const knowledge = ['resolved','open','draft_only'].map(k => ({ id: `y1358n_k_${k}`, name: `知识点 ${k} / 条件与歧义`, domain: 'math', created_at: now, updated_at: now }));
  const questions = [
    { id: 'y1358n_q_active', draft_status: 'active', knowledge_ids: ['y1358n_k_resolved'] },
    { id: 'y1358n_q_null', draft_status: null, knowledge_ids: ['y1358n_k_resolved'] },
    { id: 'y1358n_q_future', draft_status: 'future_status', knowledge_ids: ['y1358n_k_resolved','y1358n_k_missing'] },
    { id: 'y1358n_q_draft', draft_status: 'draft', knowledge_ids: ['y1358n_k_resolved','y1358n_k_draft_only'] },
    { id: 'y1358n_q_blank', draft_status: 'active', knowledge_ids: [], prompt_md: ' \n ' },
  ].map(q => ({ kind: 'calculation', prompt_md: `  ${LONG_TEXT}  `, difficulty: 3, source: 'test', created_at: now, updated_at: now, ...q }));
  const signals = ['question_pool_gap','coverage_thin','misconception','pattern_hint','quality','offtopic','future_signal','unknown'];
  const notes = Array.from({ length: 205 }, (_, i) => {
    const id = `y1358n_note_${String(i).padStart(3,'0')}`;
    const payload = { target_agents: i % 2 ? ['maintenance','research_meeting'] : ['coach','dreaming'], refs: structuredClone(refs),
      summary_md: `${i}: ${LONG_TEXT}`, signal_kind: signals[i % signals.length], source_task_kind: i % 3 ? 'quiz_verify' : 'future_agent',
      source_task_run_id: `y1358n_run_${i}`, confidence: i % 5 ? 0.81 : 0, provenance,
      caused_by_event_id: 'payload_cause_must_not_win', ...(i % 2 ? { expires_at: '2099-01-01T00:00:00.000Z' } : {}) };
    // The top 20 are fresh. The next 15 are yesterday, the remainder earlier.
    if (i < 185) { const primary = payload.refs.splice(i >= 170 ? 1 : 2,1)[0]; payload.refs.unshift(primary); }
    const age = i >= 185 ? 0 : i >= 170 ? 86400000 : 172800000;
    return { id, actor_kind: 'agent', actor_ref: 'actor_fallback', action: 'experimental:agent_note', subject_kind: 'query', subject_id: id,
      created_at: new Date(+now-age), payload, caused_by_event_id: 'y1358n_column_cause', task_run_id: `y1358n_run_${i}` };
  });
  // Topmost two retain actor fallback and absent optional fields; they remain visible on Today.
  delete notes[204].payload.source_task_kind; delete notes[204].payload.source_task_run_id;
  delete notes[204].payload.confidence; notes[204].payload.refs = []; notes[204].caused_by_event_id = 'y1358n_original_event';
  const negative = ['expired','at_boundary','wrong_action','wrong_subject'].map((kind, i) => ({ ...notes[203], id: `y1358n_${kind}`, subject_id: `y1358n_${kind}`,
    payload: { ...notes[203].payload, expires_at: i === 0 ? '2000-01-01T00:00:00.000Z' : i === 1 ? now.toISOString() : '2099-01-01T00:00:00.000Z' },
    ...(kind === 'wrong_action' ? { action: 'experimental:other' } : {}), ...(kind === 'wrong_subject' ? { subject_kind: 'question' } : {}) }));
  const goal = ['active','done'].map(status => ({ id: `y1358n_goal_${status}`, title: `合成目标 / ${status} / 条件与证据`, status, source: 'manual', created_at: now, updated_at: now }));
  const session = { id: 'y1358n_review_session', type: 'review', status: 'completed', summary_md: '合成复习 2 题，无评分或 AI 调用', started_at: new Date(+now-60000), ended_at: now };
  const events = [0,1].map(i => ({ id: `y1358n_user_review_${i}`, session_id: session.id, actor_kind: 'user', actor_ref: 'self', action: 'review', subject_kind: 'question', subject_id: questions[i].id,
    payload: { fsrs_rating: 'good', synthetic_seed: true }, created_at: now }));
  events.push({ id: 'y1358n_original_event', actor_kind: 'user', actor_ref: 'self', action: 'experimental:synthetic_evidence', subject_kind: 'query', subject_id: 'y1358n_original_event', payload: { text: LONG_TEXT, synthetic_seed: true }, created_at: now });
  return { knowledge, questions, notes, negative, goal, session, events, clock: now.toISOString() };
}
export async function seedFixture(db) {
  const { knowledge, question, event, goal, learning_session } = await import('../../src/db/schema.ts');
  const f = makeFixture(new Date());
  await db.transaction(async tx => {
    await tx.insert(knowledge).values(f.knowledge);
    await tx.insert(question).values(f.questions);
    await tx.insert(goal).values(f.goal);
    await tx.insert(learning_session).values(f.session);
    await tx.insert(event).values([...f.events, ...f.notes, ...f.negative]);
  });
  return { clock: f.clock, eligible_count: f.notes.length, note_ids: f.notes.map(n=>n.id), excluded_ids: f.negative.map(n=>n.id),
    boundary_id: 'y1358n_at_boundary', expiry_policy: 'actual wall clock, 2099/2000/no-expiry; exact boundary checked only with emitted public entry at recorded seed clock',
    seed_scope: 'synthetic direct fixture insertion in an isolated transaction; no scoring dispatch, AI, config mutation or worker',
    today_evidence: { knowledge: 3, question: 5, goal_history: 2, active_goal: 1, completed_review_session: 1, user_review_events: 2 },
    known_unknown_signals: [...new Set(f.notes.map(n=>n.payload.signal_kind))] };
}
