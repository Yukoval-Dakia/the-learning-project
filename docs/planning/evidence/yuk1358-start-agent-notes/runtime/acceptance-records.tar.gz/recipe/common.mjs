import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, realpathSync, statSync } from 'node:fs';

export const ROOT = '/Volumes/YukovalSBak/yukoval-projects/tlp-yuk1352-start-frontdoor';
export const BRANCH = 'feat/yuk-1358-start-agent-notes';
export const PREPARED_HEAD = 'c10e1188528a04c789d6aff1dac2eafee4db6cba';
export const PREPARED_SOURCE_HEAD = '8bfc4d20354679b6e428b38359385bcb0cdf0cab';
export const OPS = ['getStartAgentNoteBoard'];
export const hash = bytes => createHash('sha256').update(bytes).digest('hex');
export const stable = x => Array.isArray(x) ? x.map(stable) : x && typeof x === 'object'
  ? Object.fromEntries(Object.keys(x).sort().map(k => [k, stable(x[k])])) : x;
export const digest = x => hash(JSON.stringify(stable(x)));
export function parseMap(text) {
  const out = {}; const ids = new Set();
  for (const m of text.matchAll(/"([a-f0-9]{64})"\s*:\s*\{\s*functionName:\s*"([A-Za-z0-9_]+)_createServerFn_handler"/g)) {
    assert(!out[m[2]] && !ids.has(m[1]), 'duplicate resolver name/id');
    out[m[2]] = m[1]; ids.add(m[1]);
  }
  for (const n of OPS) assert(out[n], `resolver missing ${n}`);
  return out;
}
export function checkLock(c) {
  assert.equal(c.authorized, '1', 'parent runtime authorization required');
  assert(c.owner && c.token && c.record && c.recordHash, 'actual lock owner/token/record/hash required');
  assert(c.record.startsWith('/') && realpathSync(c.record) === c.record, 'lock record must be absolute canonical path');
  assert(c.record.includes('/deployment.lock/'), 'record must live inside deployment.lock directory');
  const info = statSync(c.record); assert(info.isFile(), 'lock record must be a regular file');
  const bytes = readFileSync(c.record); assert.equal(hash(bytes), c.recordHash, 'lock record changed');
  const value = JSON.parse(bytes);
  // Parent supplies the actual field paths if its native record uses different names.
  const field = path => path.split('.').reduce((v, k) => v?.[k], value);
  assert.equal(field(c.ownerField ?? 'owner'), c.owner, 'lock owner mismatch');
  assert.equal(field(c.tokenField ?? 'token'), c.token, 'lock token mismatch');
  assert((process.umask() & 0o077) === 0o077, 'runtime requires umask 077');
  return { record: c.record, sha256: c.recordHash, owner: c.owner };
}
export function assertReadOnly(before, after) {
  for (const k of ['tables', 'relations', 'columns', 'constraints', 'sequences', 'boss'])
    assert.deepEqual(after[k], before[k], `read window changed ${k}`);
  assert.equal(after.boss, false);
}
