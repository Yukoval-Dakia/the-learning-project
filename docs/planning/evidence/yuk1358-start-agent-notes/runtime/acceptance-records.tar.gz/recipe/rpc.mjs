import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import { hash, digest, assertReadOnly } from './common.mjs';
export async function runAcceptance({ app, host, client, x, seal, fixture, write, snapshot, lock, log }) {
  const { serve } = await import('@hono/node-server');
  const { serverFnFetcher } = await import(pathToFileURL(seal.build.framework.fetcher));
  const { runWithStartContext } = await import(pathToFileURL(seal.build.framework.storage));
  const base = `http://127.0.0.1:${x.http_port}`;
  const id = seal.build.functions.getStartAgentNoteBoard;
  // Actual TCP loopback listener uses the retained emitted Hono and exact built Start.
  const server = serve({ fetch: app.fetch, hostname: '127.0.0.1', port: x.http_port });
  await new Promise((resolve,reject) => { server.once('error',reject); server.once('listening',resolve); });
  let calls = 0, windows = 0;
  async function ro(name, fn) {
    lock(); const before = await snapshot(`${++windows}-${name}-before`);
    const result = await fn(); const after = await snapshot(`${windows}-${name}-after`);
    assertReadOnly(before,after); write(`${windows}-${name}-no-write.json`, { equal: true, public_tables:88, sequences_equal:true, full_relations_equal:true }); return result;
  }
  async function rpc(data, options = {}) {
    lock(); let wire, envelope, error;
    const headers = options.token === null ? {} : { 'x-internal-token': options.token ?? x.token };
    const transport = async (url, init) => {
      const target = new URL(url,base); assert.equal(target.origin,base); assert.equal(target.pathname,`/_serverFn/${id}`);
      const request = new Request(target,init), started_at = new Date().toISOString();
      // Never fulfill from a test DTO or invoke app.fetch directly for the claimed RPC.
      const response = await fetch(request); const body = await response.clone().text();
      wire = { call: ++calls, function:'getStartAgentNoteBoard', id, method:request.method,
        path:target.pathname, query:target.search, request_header_names:[...request.headers.keys()],
        request_body:typeof init.body==='string'?init.body:null, started_at, finished_at:new Date().toISOString(),
        status:response.status, response_headers:Object.fromEntries(response.headers), response_sha256:hash(body), response_body:body,
        transport:'actual TCP loopback', token_class: options.token===null?'missing':options.token?'wrong':'valid' };
      log(wire); return response;
    };
    try {
      envelope = await runWithStartContext({ startOptions:{}, request:new Request(base), handlerType:'serverFn',
        contextAfterGlobalMiddlewares:{}, executedRequestMiddlewares:new Set(), getRouter(){throw new Error('client must not create router');} },
        () => serverFnFetcher(`${base}/_serverFn/${id}`,[{ method:'GET',data,headers,fetch:transport }],transport));
    } catch(e) { error=e; }
    assert.equal(wire?.status,options.status??200,'unexpected actual RPC status');
    if(options.status && options.status!==200) {
      const body=JSON.parse(wire.response_body);
      if(options.status===401) assert.equal(body.error,'unauthorized');
      if(options.status===503) { assert.equal(body.error,'contract_epoch_fenced'); assert.equal(body.state,options.epoch); }
      if(options.status===400) assert.equal(body.error,'validation_error');
      return body;
    }
    if(error) throw error;
    assert.equal(wire.response_headers['x-tss-serialized'],'true');
    assert(envelope && Object.hasOwn(envelope,'result')); assert.equal(envelope.error,undefined);
    write(`rpc-${wire.call}-dto.json`,envelope.result); return envelope.result;
  }
  async function epoch(kind) {
    // Setup mutation has its own markers and never enters the read-window claim.
    const before=await snapshot(`epoch-${kind}-before`); const result=await host.epoch(kind);
    const after=await snapshot(`epoch-${kind}-after`);
    const changed=Object.keys(before.tables).filter(k=>digest(before.tables[k])!==digest(after.tables[k]));
    assert.deepEqual(changed,['public.contract_epoch']);
    assert.deepEqual(before.relations,after.relations); assert.deepEqual(before.sequences,after.sequences);
    write(`epoch-${kind}-receipt.json`,{...result, classification:'isolated epoch setup mutation'});
  }
  async function http(limit, status=200, token=x.token) {
    const url=`${base}/api/agents/notes${limit===undefined?'':`?limit=${encodeURIComponent(limit)}`}`;
    const response=await fetch(url,{headers:{'x-internal-token':token}}); const body=await response.json();
    log({kind:'actual HTTP parity',path:new URL(url).pathname+new URL(url).search,status:response.status,body,clock:new Date().toISOString()});
    assert.equal(response.status,status); return body;
  }
  try {
    await epoch('begin_prepare');
    await ro('auth-before-fence-and-malformed',async()=>{
      for(const data of ['malformed-domain-input',{limit:201},null]) for(const token of [null,'wrong-synthetic-token']) await rpc(data,{token,status:401});
    });
    await ro('preparing-before-malformed',async()=>{
      for(const data of ['malformed-domain-input',{limit:201},null]) await rpc(data,{status:503,epoch:'preparing'});
    });
    await epoch('mark_ready');
    await ro('ready-before-malformed',async()=>{ await rpc({limit:201},{status:503,epoch:'ready'}); });
    await epoch('activate');
    // No pending expires_at in this interval: seed boundary is past, 2099 is future.
    assert(Date.now()>=Date.parse(fixture.clock)); assert(new Date().getUTCFullYear()<2099);
    const boundary=await ro('emitted-public-exact-boundary',async()=>{
      const clock=new Date(fixture.clock);
      const exact=await host.publicBoard({limit:200},clock);
      assert(!exact.rows.some(r=>r.id===fixture.boundary_id));
      // Boundary note sorts near top, so it cannot disappear due to the 200 cap.
      const before=await host.publicBoard({limit:200},new Date(+clock-1));
      assert(before.rows.some(r=>r.id===fixture.boundary_id));
      write('public-boundary-proof.json',{clock:clock.toISOString(),clock_before:new Date(+clock-1).toISOString(),boundary:fixture.boundary_id,strict_expiry:true,
        scope:'real emitted public selector with injected clock, separate from actual RPC wall-clock'});
      return exact;
    });
    const allBefore=await snapshot('rpc-read-window-before');
    for(const limit of [undefined,20,50,200]) await ro(`valid-${limit??'default'}`,async()=>{
      const actual=await rpc(limit===undefined?{}:{limit});
      const now=new Date(); const canonical=await host.publicBoard(limit===undefined?{}:{limit},now);
      const response=await http(limit);
      assert.deepEqual(actual,canonical); assert.deepEqual(actual,response);
      assert.equal(actual.rows.length,limit??20);
      assert(actual.rows.every(r=>typeof r.created_at==='string' && new Date(r.created_at).toISOString()===r.created_at));
      assert(!actual.rows.some(r=>fixture.excluded_ids.includes(r.id)));
      const rich=actual.rows.find(r=>r.id==='y1358n_note_203'); assert(rich);
      assert(rich.summary_md.length>8000); assert.equal(rich.caused_by_event_id,'y1358n_column_cause');
      const refs=new Map(rich.refs.map(r=>[r.id,r]));
      assert.equal(refs.get('y1358n_k_resolved').usable_question_count,3);
      for(const k of ['open','draft_only']) { assert.equal(refs.get(`y1358n_k_${k}`).resolution_state,'open'); assert.equal(refs.get(`y1358n_k_${k}`).usable_question_count,0); }
      assert.equal(refs.get('y1358n_k_missing').resolution_state,'unknown');
      for(const k of ['active','null','future','blank']) assert.equal(refs.get(`y1358n_q_${k}`).resolution_state,'resolved');
      assert.equal(refs.get('y1358n_q_draft').resolution_state,'open'); assert.equal(refs.get('y1358n_q_missing').resolution_state,'unknown');
      assert.deepEqual(refs.get('y1358n_unknown_α').extra,{nested:[null,'原件',{confidence:0}]});
      assert(refs.get('y1358n_k_resolved').provenance.source.excerpts[0].length>8000);
      const forever=actual.rows.find(r=>r.id==='y1358n_note_204'); assert(forever); assert(!Object.hasOwn(forever,'expires_at'));
      assert.equal(forever.source_task_kind,'actor_fallback'); assert(!Object.hasOwn(forever,'source_task_run_id')); assert(!Object.hasOwn(forever,'confidence'));
      write(`parity-${limit??'default'}.json`,{rows:actual.rows.length,actual_clock:now.toISOString(),dto_sha256:digest(actual),http_public_rpc_equal:true});
    });
    // Empty object is the canonical default; an absent object is malformed.
    await ro('string-limit-and-absent-input',async()=>{ assert.equal((await rpc({limit:'50'})).rows.length,50); await rpc(undefined,{status:400}); });
    await ro('invalid-limits-and-input',async()=>{
      for(const limit of [0,-1,201,999,'201','1.5','text']) {
        const denial=await rpc({limit},{status:400}); assert.deepEqual(denial,await http(limit,400));
      }
      for(const input of [null,'malformed-domain-input',[]]) await rpc(input,{status:400});
    });
    const allAfter=await snapshot('rpc-read-window-after'); assertReadOnly(allBefore,allAfter);
    write('rpc-summary.json',{calls,windows,public_tables:88,sequences_equal:true,full_relations_equal:true,fixture_eligible:205,
      exact_public_boundary:boundary.rows.length, actual_loopback:true, installed_fetcher_seroval:true, domain_not_mocked:true, browser:'pending'});
  } finally {
    server.closeAllConnections?.(); await new Promise(resolve=>server.close(resolve));
  }
}
