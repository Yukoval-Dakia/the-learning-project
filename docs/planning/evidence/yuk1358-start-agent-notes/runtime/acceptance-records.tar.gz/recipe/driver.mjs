import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { randomBytes, randomUUID } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, readdirSync, realpathSync, statSync, writeFileSync, appendFileSync } from 'node:fs';
import { dirname, join, relative } from 'node:path';
import { createRequire, Module, syncBuiltinESMExports } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';
import net from 'node:net';
import tls from 'node:tls';
import dgram from 'node:dgram';
import { ROOT, BRANCH, PREPARED_HEAD, PREPARED_SOURCE_HEAD, hash, digest, parseMap, checkLock } from './common.mjs';
import { transformHost } from './host-transform.mjs';
import { seedFixture } from './fixture.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
const [mode, run, label] = process.argv.slice(2);
assert(['offline', 'seal', 'verify', 'setup', 'seed', 'rpc', 'serve', 'snapshot', 'compare', 'cleanup'].includes(mode));
assert.equal(process.argv.length, ['snapshot', 'compare'].includes(mode) ? (mode === 'compare' ? 6 : 5) : ['offline', 'seal', 'verify'].includes(mode) ? 3 : 4);
if (run) assert(/^[a-z0-9][a-z0-9-]{0,63}$/.test(run));
if (label) assert(/^[a-z0-9][a-z0-9-]{0,63}$/.test(label));
const RUN = run ? join(HERE, 'runs', run) : null;
const c = {
  authorized: process.env.YUK1358_PARENT_ACCEPTANCE,
  owner: process.env.YUK1358_LOCK_OWNER, token: process.env.YUK1358_LOCK_TOKEN,
  record: process.env.YUK1358_LOCK_RECORD, recordHash: process.env.YUK1358_LOCK_RECORD_SHA256,
  ownerField: process.env.YUK1358_LOCK_OWNER_FIELD, tokenField: process.env.YUK1358_LOCK_TOKEN_FIELD,
  image: process.env.YUK1358_PG_IMAGE_ID, docker: process.env.DOCKER_HOST,
};
const clean = Object.fromEntries(['PATH', 'TMPDIR', 'LANG', 'LC_ALL'].filter(k => process.env[k]).map(k => [k, process.env[k]]));
for (const key of Object.keys(process.env)) delete process.env[key];
Object.assign(process.env, clean, { NODE_ENV: 'production', RW_WORKER: '0' });
if (c.docker) process.env.DOCKER_HOST = c.docker;
const pause = ms => new Promise(r => setTimeout(r, ms));
const write = (name, value) => writeFileSync(join(RUN, name), JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
const read = name => JSON.parse(readFileSync(join(RUN, name), 'utf8'));
function cmd(exe, args, timeout = 30000) {
  const r = spawnSync(exe, args, { cwd: ROOT, env: process.env, encoding: 'utf8', timeout, maxBuffer: 32 * 1024 * 1024 });
  assert(!r.error && r.status === 0, `${exe} ${args[0]} failed; preserve failure and inspect command output privately`);
  return r.stdout.trim();
}
function files(dir) {
  return readdirSync(join(ROOT, dir)).sort().flatMap(n => {
    const p = join(dir, n); const s = statSync(join(ROOT, p));
    assert.equal(realpathSync(join(ROOT, p)), join(ROOT, p), 'artifact symlink refused');
    return s.isDirectory() ? files(p) : [p];
  });
}
function manifest(paths) { return Object.fromEntries(paths.sort().map(p => [p, hash(readFileSync(join(ROOT, p)))])); }
const docsOnly = p => /^(docs\/|\.remember\/|PLAN\.md$|README\.md$|MEMORY\.md$)/.test(p);
function source() {
  assert.equal(realpathSync(process.cwd()), ROOT);
  const head = cmd('git', ['rev-parse', 'HEAD']);
  assert.equal(cmd('git', ['branch', '--show-current']), BRANCH);
  cmd('git', ['merge-base', '--is-ancestor', PREPARED_HEAD, head]);
  cmd('git',['merge-base','--is-ancestor',PREPARED_SOURCE_HEAD,head]);
  const integration=cmd('git',['diff','--name-only','-z',PREPARED_HEAD,PREPARED_SOURCE_HEAD]).split('\0').filter(p=>p&&!docsOnly(p));
  assert.deepEqual(integration,['web/src/routes/AdminControls.start.unit.test.tsx','web/src/routes/AdminPages.start.unit.test.tsx']);
  const changes = cmd('git', ['diff', '--name-only', '-z', PREPARED_SOURCE_HEAD, head]).split('\0').filter(Boolean);
  assert(changes.every(docsOnly), 'post-candidate commit must contain docs/evidence only');
  const tracked = cmd('git', ['ls-files','-z']).split('\0').filter(p => p && !docsOnly(p));
  const dirty = cmd('git', ['diff', 'HEAD', '--name-only','-z']).split('\0').filter(Boolean);
  assert(dirty.every(docsOnly), 'tracked product dirty');
  const extra = cmd('git', ['ls-files', '--others', '--exclude-standard','-z']).split('\0').filter(Boolean);
  assert(extra.every(docsOnly), 'untracked product files refused');
  cmd('git', ['check-ignore', join(HERE, 'driver.mjs')]);
  const all = manifest(tracked);
  return { candidate: PREPARED_HEAD, source_baseline:PREPARED_SOURCE_HEAD, parent_test_only_repairs:integration, observed_head: head, branch: BRANCH, files: all, sha256: digest(all), node: process.version,
    permitted_later_commits: 'docs/evidence only; identical product bytes and build/dependencies required' };
}
function framework() {
  const client = realpathSync(fileURLToPath(import.meta.resolve('@tanstack/react-start/client-rpc')));
  const startRequire = createRequire(client);
  const core = startRequire.resolve('@tanstack/start-client-core/package.json');
  const fetcher = join(dirname(core), 'dist/esm/client-rpc/serverFnFetcher.js');
  const r = createRequire(core);
  const storage = r.resolve('@tanstack/start-storage-context/package.json');
  const serovalEntry = r.resolve('seroval');
  let serovalPackage = dirname(serovalEntry); while (!existsSync(join(serovalPackage,'package.json'))) { const up=dirname(serovalPackage); assert.notEqual(up,serovalPackage); serovalPackage=up; }
  const router = r.resolve('@tanstack/router-core/package.json');
  const serovalEsm = join(serovalPackage,JSON.parse(readFileSync(join(serovalPackage,'package.json'),'utf8')).exports['.'].import);
  function implementationFiles(dir) { return readdirSync(dir).sort().flatMap(n=>{const p=join(dir,n);return statSync(p).isDirectory()?implementationFiles(p):/\.(js|mjs|cjs)$/.test(n)?[p]:[];}); }
  const paths = [...implementationFiles(join(dirname(core),'dist/esm')), ...implementationFiles(join(dirname(router),'dist/esm')), serovalEsm, router, client, core, join(serovalPackage,'package.json'), fetcher, serovalEntry, join(dirname(core), 'dist/esm/getDefaultSerovalPlugins.js'), join(dirname(storage), 'dist/esm/index.js')];
  return { fetcher, storage: join(dirname(storage),'dist/esm/index.js'), files: Object.fromEntries([...new Set(paths)].map(p => [relative(ROOT, p), hash(readFileSync(p))])) };
}
function build() {
  const paths = ['dist/server.cjs', ...files('dist/start'), ...files('web/dist')];
  const all = manifest(paths);
  const resolvers = paths.filter(p => /server-fn-resolver.*\.js$/.test(p)); assert.equal(resolvers.length, 1);
  const author = JSON.parse(readFileSync(join(ROOT,'docs/planning/evidence/yuk1358-start-agent-notes/hashes.json'),'utf8'));
  for (const [p,h] of Object.entries({...author.source_files,...author.artifact_files})) assert.equal(hash(readFileSync(join(ROOT,p))),h, `author manifest drift ${p}`);
  const transformed = transformHost(readFileSync(join(ROOT, 'dist/server.cjs'), 'utf8'));
  const dbChunks = paths.filter(p => p.startsWith('dist/start/server/assets/') && p.endsWith('.js') && readFileSync(join(ROOT,p),'utf8').includes('//#region src/db/client.ts'));
  assert.equal(dbChunks.length,1);
  const dbText = readFileSync(join(ROOT,dbChunks[0]),'utf8');
  const alias = dbText.match(/export \{[^}]*\bdb as (\w+)[^}]*\}/)?.[1]; assert(alias);
  return { author_manifest: { source_sha256:author.source_sha256, artifact_sha256:author.artifact_sha256 }, esm_db: { path: dbChunks[0], export: alias }, files: all, sha256: digest(all), resolver: resolvers[0], functions: parseMap(readFileSync(join(ROOT, resolvers[0]), 'utf8')), framework: framework(), host: transformed.proof };
}
function recipe() {
  return Object.fromEntries(readdirSync(HERE).filter(n => /\.(mjs|md|js|sh|example)$/.test(n)).sort().map(n => [n, hash(readFileSync(join(HERE, n)))]));
}
function immutable() {
  const seal = JSON.parse(readFileSync(join(HERE, 'seal.json')));
  assert.equal(source().sha256, seal.source.sha256, 'source drift after seal');
  assert.equal(source().candidate, seal.source.candidate);
  assert.deepEqual(recipe(), seal.recipe, 'recipe drift after seal');
  assert.deepEqual(build(), seal.build, 'build/dependencies drift after seal');
  return seal;
}
function authorized() {
  checkLock(c);
  assert(Number(process.versions.node.split('.')[0]) >= 24, 'Node >=24 required');
  assert(c.docker?.startsWith('unix://') && existsSync(c.docker.slice(7)), 'explicit local Docker socket required');
}
function state() {
  const x = read('private-state.json'); assert.equal(x.run, run); assert.equal(x.root, ROOT);
  assert.equal(x.lock_hash, c.recordHash); assert.equal(x.lock_token_hash, hash(c.token)); assert.equal(x.lock_owner, c.owner);
  assert(/^sha256:[a-f0-9]{64}$/.test(x.image)); assert(/^[a-f0-9]{64}$/.test(x.container));
  assert.equal(x.http_port,18954); assert.notEqual(x.port,x.http_port);
  assert(/^y1358n_[a-f0-9]{32}$/.test(x.database));
  for (const url of [x.admin_url, x.app_url]) {
    const u = new URL(url); assert.equal(u.hostname, '127.0.0.1'); assert.equal(u.pathname, `/${x.database}`);
    assert.equal(Number(u.port), x.port); assert(![5432, 18994, 18995, 18952].includes(x.port));
  }
  return x;
}
function owned(x) {
  checkLock(c);
  const info = JSON.parse(cmd('docker', ['inspect', x.container]))[0];
  assert.equal(info.Id, x.container); assert.equal(info.Image, x.image);
  assert.equal(info.Config.Labels['yuk1358.agentnotes.owner'], x.owner);
  assert.equal(info.Config.Labels['yuk1358.agentnotes.lock'], x.lock_token_hash);
  const binding = info.HostConfig.PortBindings['5432/tcp'];
  assert.equal(binding[0].HostIp, '127.0.0.1');
  if (x.port) assert.equal(Number(info.NetworkSettings.Ports['5432/tcp'][0].HostPort), x.port);
  return info;
}
async function connection(x, identity = true) {
  owned(x);
  const { default: postgres } = await import('postgres');
  const client = postgres(x.admin_url, { max: 1, ssl: false, connect_timeout: 5, idle_timeout: 5, onnotice() {} });
  try {
    if (identity) {
      const [row] = await client`select current_database() as db, owner_id from yuk1358_agentnotes.identity`;
      assert.equal(row.db, x.database); assert.equal(row.owner_id, x.owner);
    }
    return client;
  } catch (e) { await client.end({ timeout: 3 }); throw e; }
}
export async function snapshot(client, name) {
  const result = await client.begin('isolation level repeatable read read only', async tx => {
    const relations = await tx`select n.nspname as schema,c.relname as name,c.relkind as kind,
      case when c.relkind in ('v','m') then pg_get_viewdef(c.oid,true) when c.relkind in ('i','I') then pg_get_indexdef(c.oid) else null end as definition
      from pg_class c join pg_namespace n on n.oid=c.relnamespace
      where n.nspname not in ('pg_catalog','information_schema') and n.nspname not like 'pg_toast%' and n.nspname not like 'pg_temp%' order by 1,2`;
    const columns = await tx`select table_schema,table_name,column_name,data_type,udt_name,is_nullable,column_default,ordinal_position
      from information_schema.columns where table_schema not in ('pg_catalog','information_schema') order by 1,2,8`;
    const constraints = await tx`select n.nspname as schema,c.relname as relation,k.conname as name,pg_get_constraintdef(k.oid,true) as definition
      from pg_constraint k join pg_class c on c.oid=k.conrelid join pg_namespace n on n.oid=c.relnamespace
      where n.nspname not in ('pg_catalog','information_schema') order by 1,2,3`;
    const tables = {}, sequences = {};
    for (const r of relations) {
      const key = `${r.schema}.${r.name}`;
      if (r.kind === 'S') sequences[key] = await tx`select last_value::text,is_called from ${tx(r.schema)}.${tx(r.name)}`;
      if (['r','p','m'].includes(r.kind)) {
        const rows = (await tx`select to_jsonb(t) as row from ${tx(r.schema)}.${tx(r.name)} t order by to_jsonb(t)::text`).map(r=>r.row);
        tables[key] = { count: rows.length, sha256: digest(rows) };
      }
    }
    const [boss] = await tx`select to_regnamespace('pgboss') is not null as present`;
    const count = relations.filter(r => r.schema === 'public' && ['r','p'].includes(r.kind)).length;
    assert.deepEqual(relations.filter(r => r.schema === "public" && ["r","p"].includes(r.kind)).map(r=>r.name).sort(), ["ai_task_runs", "answer", "artifact", "artifact_block_ref", "artifact_edit_session", "assessment_identity_mapping", "assessment_issuance", "assessment_response_draft", "assessment_submission", "cause_category_overlay", "completion_evidence", "contract_epoch", "copilot_continuation", "copilot_evidence_checkpoint", "cost_ledger", "dag_orchestration_node", "dag_orchestration_run", "difficulty_calibration_label", "echo_jobs", "edge_reconciliation_log", "editing_presence", "evaluation", "evaluation_effective_head", "evaluation_group", "event", "event_subscription_checkpoint", "event_subscription_delivery", "event_subscription_effect", "goal", "hub_sync_reconciliation", "intervention", "item_calibration", "item_family_calibration", "job_events", "kc_typed_state", "knowledge", "knowledge_edge", "learner_axis_state", "learning_item", "learning_record", "learning_session", "mastery_state", "material_fsrs_state", "materialized_id_index", "memory_brief_note", "memory_reconciliation_log", "migration_apply_phase", "migration_apply_run", "misconception", "misconception_edge", "misconception_reconciliation_log", "mistake_variant", "note_verification_claim", "placement_starter_attempt", "placement_starter_attempt_question", "placement_starter_claim", "placement_starter_cost_component", "practice_stream_item", "proposal_signals", "provider_attempt", "provider_attempt_admission", "provider_session_admission", "prune_job_events_control", "prune_job_events_disposition", "prune_job_events_receipt", "question", "question_admission_verification", "question_answer_anchor", "question_block", "question_generation_binding", "question_generation_plan", "question_group_lifecycle", "question_revision", "selection_observation", "source_asset", "source_document", "subagent_run", "subject", "subject_control_journal", "subject_name_claim", "subject_trait", "subject_trait_binding", "subject_trait_journal", "system_config", "system_config_epoch", "system_config_journal", "tool_call_log", "tool_operation"], "migration-derived exact public table inventory");
    assert(!boss.present);
    return { relations, columns, constraints, tables, sequences, public_table_count: count, boss: boss.present };
  });
  write(`${name}.json`, { ...result, captured_at: new Date().toISOString(), sha256: digest(result) }); return result;
}
async function setup(seal) {
  mkdirSync(join(HERE, 'runs'), { recursive: true }); mkdirSync(RUN);
  write('setup-started.json', { head: source().observed_head, lock: checkLock(c), build: seal.build.sha256 });
  assert(/^sha256:[a-f0-9]{64}$/.test(c.image ?? ''), 'parent must pin locally installed PG image ID; driver never pulls');
  write('docker-preflight.json', { version: cmd('docker',['version','--format','{{json .}}']), image:c.image, endpoint:'explicit local unix socket', no_pull:true });
  const info = JSON.parse(cmd('docker', ['image', 'inspect', c.image]))[0]; assert.equal(info.Id, c.image);
  const owner = randomUUID(); const database = `y1358n_${randomUUID().replaceAll('-', '')}`;
  const password = randomBytes(24).toString('hex'); const appPassword = randomBytes(24).toString('hex');
  writeFileSync(join(RUN, 'postgres.env'), `POSTGRES_DB=${database}\nPOSTGRES_USER=y1358n_seed\nPOSTGRES_PASSWORD=${password}\n`, { flag: 'wx' });
  write('setup-intent.json', { owner, database, image: c.image, lock_token_hash: hash(c.token) });
  const container = cmd('docker', ['create', '--label', `yuk1358.agentnotes.owner=${owner}`, '--label', `yuk1358.agentnotes.lock=${hash(c.token)}`,
    '-p', '127.0.0.1::5432', '--env-file', join(RUN, 'postgres.env'), c.image]);
  const initial = { root: ROOT, run, owner, database, container, image: c.image, lock_owner: c.owner, lock_hash: c.recordHash, lock_token_hash: hash(c.token) };
  write('owned-container.json', initial); owned(initial); cmd('docker', ['start', container]);
  const live = JSON.parse(cmd('docker', ['inspect', container]))[0];
  const port = Number(live.NetworkSettings.Ports['5432/tcp'][0].HostPort);
  const x = { ...initial, port, admin_url: `postgres://y1358n_seed:${password}@127.0.0.1:${port}/${database}`, app_url: `postgres://y1358n_app:${appPassword}@127.0.0.1:${port}/${database}`, token: randomBytes(32).toString('hex'), http_port: 18954 };
  write('private-state.json', x); writeFileSync(join(RUN, 'browser-token.txt'), x.token + '\n', { flag: 'wx' });
  writeFileSync(join(RUN,'synthetic-app.env'), `DATABASE_URL=${x.app_url}\nINTERNAL_TOKEN=${x.token}\nAPI_PORT=${x.http_port}\nNODE_ENV=production\nRW_WORKER=0\n`, {flag:'wx'}); state();
  let ready = false;
  for (let i = 0; i < 60; i++) {
    checkLock(c); const r = spawnSync('docker', ['exec', container, 'pg_isready', '-h', '127.0.0.1', '-U', 'y1358n_seed', '-d', database], { env: process.env, timeout: 1500 });
    if (r.status === 0) { ready = true; break; } await pause(500);
  }
  assert(ready, 'isolated PG startup deadline exceeded; cleanup exact owned resource');
  denyExternalNetwork(x);
  const client = await connection(x, false);
  try {
    const [{ drizzle }, { migrate }] = await Promise.all([import('drizzle-orm/postgres-js'), import('drizzle-orm/postgres-js/migrator')]);
    await migrate(drizzle(client), { migrationsFolder: join(ROOT, 'drizzle') });
    await client.unsafe('create schema yuk1358_agentnotes'); await client.unsafe('create table yuk1358_agentnotes.identity(owner_id text primary key)');
    await client`insert into yuk1358_agentnotes.identity values (${owner})`;
    await client.unsafe(`CREATE ROLE y1358n_app LOGIN PASSWORD '${appPassword}'`);
    await client.unsafe("ALTER ROLE y1358n_app SET statement_timeout = '15s'");
    await client.unsafe("ALTER ROLE y1358n_app SET lock_timeout = '5s'");
    await client.unsafe(`REVOKE CREATE ON DATABASE "${database}" FROM PUBLIC, y1358n_app`);
    await client.unsafe('REVOKE CREATE ON SCHEMA public FROM PUBLIC, y1358n_app');
    await client.unsafe(`GRANT CONNECT ON DATABASE "${database}" TO y1358n_app`);
    await client.unsafe('GRANT USAGE ON SCHEMA public TO y1358n_app');
    await client.unsafe('GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA public TO y1358n_app');
    await client.unsafe('GRANT USAGE,SELECT,UPDATE ON ALL SEQUENCES IN SCHEMA public TO y1358n_app');
    await snapshot(client, 'setup-baseline');
  } finally { await client.end({ timeout: 3 }); }
  write('setup-ready.json', { image: c.image, port, database, no_ryuk_worker_listener: true });
}
async function seed(x) {
  assert(existsSync(join(RUN, 'setup-ready.json'))); write('seed-started.json', { at: new Date().toISOString() });
  process.env.DATABASE_URL = x.admin_url; process.env.INTERNAL_TOKEN = x.token;
  const { db } = await import('../../src/db/client.ts');
  try {
    const fixture = await seedFixture(db);
    write('seed.json', fixture);
    const { host } = await loadHost(x, immutable());
    try {
      for (const kind of ['begin_prepare','mark_ready','activate']) await host.epoch(kind);
      write('seed-epoch.json', { epoch: host.codeEpoch, state: 'active', transitions: 3 });
    } finally { await host.close(); }
    const client = await connection(x);
    try { await snapshot(client, 'seed-baseline'); } finally { await client.end({ timeout: 3 }); }
  } finally { await db.$client.end({ timeout: 3 }); }
}
async function loadHost(x, seal) {
  process.env.DATABASE_URL = x.app_url; process.env.INTERNAL_TOKEN = x.token; process.env.API_PORT = String(x.http_port);
  process.env.RW_STATIC_DIR = 'web/dist';
  // No environment-file loader runs in the transformed entry. Credentials can only be synthetic.
  assert(!Object.keys(process.env).some(k => /API_KEY|AUTH_TOKEN|PROXY|LAMINAR|OTEL|NODE_OPTIONS/.test(k)));
  const filename = join(ROOT, 'dist/server.cjs'); const transformed = transformHost(readFileSync(filename, 'utf8'));
  assert.deepEqual(transformed.proof, seal.build.host);
  writeFileSync(join(RUN, `host-${mode}.cjs`), transformed.code, { flag: 'wx' });
  write(`host-${mode}-proof.json`, transformed.proof);
  // Use the original filename for require and relative dynamic imports. No product file is changed.
  const m = new Module(filename); m.filename = filename; m.paths = Module._nodeModulePaths(dirname(filename));
  m._compile(transformed.code, filename); const host = m.exports;
  const app = await host.initialize();
  const esm = await import(pathToFileURL(join(ROOT,seal.build.esm_db.path)));
  const esmDb = esm[seal.build.esm_db.export]; assert(esmDb?.$client);
  const close = host.close; host.close = async () => { await esmDb.$client.end({ timeout:3 }); await close(); };
  return { host, app };
}
function denyExternalNetwork(x) {
  // This applies to source seed imports, emitted host modules and lazy Start chunks.
  // Admit only exact isolated PG and loopback RPC ports; browser HTTP is inbound.
  const connect = net.Socket.prototype.connect;
  net.Socket.prototype.connect = function(...args) {
    let options = args[0];
    if (Array.isArray(options)) options = options[0];
    if (typeof options === 'number') options = { port: options, host: typeof args[1] === 'string' ? args[1] : 'localhost' };
    assert(options && typeof options === 'object' && [x.port, x.http_port].includes(Number(options.port)) && ['127.0.0.1', 'localhost', '::1'].includes(options.host ?? 'localhost'), 'outbound connection blocked: only exact isolated PG and acceptance loopback HTTP allowed');
    return connect.apply(this, args);
  };
  tls.connect = () => { throw new Error('TLS/provider connection forbidden in agent-note acceptance'); };
  const fetch = globalThis.fetch;
  globalThis.fetch = (input, init) => { const u = new URL(input instanceof Request ? input.url : input); assert.equal(u.origin, `http://127.0.0.1:${x.http_port}`, 'external fetch blocked'); return fetch(input, init); };
  dgram.createSocket = () => { throw new Error('UDP/DNS socket forbidden'); };
  syncBuiltinESMExports();
  globalThis.setInterval = () => { throw new Error('background interval forbidden in agent-note acceptance'); };
}
async function serve(x, seal) {
  assert(existsSync(join(RUN, 'rpc-pass.json')), 'finish RPC before opening browser listener');
  write('serve-started.json', { pid: process.pid, bound: '127.0.0.1', port: x.http_port, no_background_listener: true });
  const { host, app } = await loadHost(x, seal);
  const { serve } = await import('@hono/node-server');
  const csp = "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; connect-src 'self'; media-src 'self' blob:; object-src 'none'; frame-src 'none'; worker-src 'none'; form-action 'self'; base-uri 'self'";
  const guardedFetch = async request => { const res = await app.fetch(request); const headers = new Headers(res.headers); headers.set('Content-Security-Policy', csp); headers.set('X-DNS-Prefetch-Control', 'off'); return new Response(res.body, {status:res.status, statusText:res.statusText, headers}); };
  const server = serve({ fetch: guardedFetch, hostname: '127.0.0.1', port: x.http_port });
  await new Promise((resolve, reject) => { server.once('error', reject); server.once('listening', resolve); });
  let stop = false; process.once('SIGINT', () => { stop = true; }); process.once('SIGTERM', () => { stop = true; });
  write('serve-ready.json', { pid: process.pid, emitted_host_sha256:seal.build.host.transformed_sha256, start_sha256:seal.build.sha256, origin: `http://127.0.0.1:${x.http_port}` });
  try {
    const deadline = Date.now() + 45 * 60 * 1000;
    while (!stop && !existsSync(join(RUN, 'stop-serve.request')) && Date.now() < deadline) { checkLock(c); await pause(500); }
  } finally {
    server.closeAllConnections?.(); await new Promise(r => server.close(r)); await host.close();
    write('serve-stopped.json', { pid: process.pid, owned_handle_only: true });
  }
}
async function cleanup() {
  // Cleanup deliberately tolerates source/build drift, but never lock/identity drift.
  if (existsSync(join(RUN, 'serve-ready.json')) && !existsSync(join(RUN, 'serve-stopped.json'))) {
    if (!existsSync(join(RUN, 'stop-serve.request'))) write('stop-serve.request', { requested: true });
    for (let i = 0; i < 60 && !existsSync(join(RUN, 'serve-stopped.json')); i++) { checkLock(c); await pause(250); }
    assert(existsSync(join(RUN, 'serve-stopped.json')), 'serve owner absent; no saved-PID kill allowed');
  }
  if (existsSync(join(RUN,'cleanup.json'))) throw new Error('cleanup already recorded; preserve receipt');
  assert(existsSync(join(RUN,'private-state.json')) || existsSync(join(RUN,'owned-container.json')), 'container identity outcome unknown; parent must inspect exact setup-intent labels, never reset run');
  const x = existsSync(join(RUN, 'private-state.json')) ? state() : read('owned-container.json');
  owned(x); cmd('docker', ['rm', '-f', x.container]);
  const ids = cmd('docker', ['ps', '-a', '--no-trunc', '--format', '{{.ID}}']).split('\n'); assert(!ids.includes(x.container));
  write('cleanup.json', { removed_exact_owned_container: x.container, lock_released: false, other_resources_touched: false });
}
async function main() {
  if (mode === 'offline') { const s = source(); console.log(JSON.stringify({ status: 'offline-recipe-only', head: s.observed_head, source_sha256: s.sha256, build_read_or_sealed: false, runtime_executed: false })); return; }
  if (mode === 'seal') {
    // Parent calls this only after its build has finished, before taking the runtime lock.
    const s = source(); const b = build(); const again = build(); assert.deepEqual(again, b, 'build changed during seal'); assert.equal(source().sha256,s.sha256,'source changed during seal');
    writeFileSync(join(HERE, 'seal.json'), JSON.stringify({ source: s, build: b, recipe: recipe(), at: new Date().toISOString(), runtime_executed: false }, null, 2) + '\n', { flag: 'wx' });
    console.log(JSON.stringify({ status: 'offline-sealed-only', head: s.observed_head, build_sha256: b.sha256 })); return;
  }
  if (mode === 'verify') { const s = immutable(); console.log(JSON.stringify({ status: 'offline-verified-only', candidate: s.source.candidate, head: source().observed_head, build_sha256: s.build.sha256, runtime_executed: false })); return; }
  authorized();
  if (mode === 'cleanup') { await cleanup(); return; }
  const seal = immutable();
  if (mode === 'setup') { await setup(seal); return; }
  const x = state(); assert(existsSync(join(RUN, 'setup-ready.json')));
  denyExternalNetwork(x);
  if (existsSync(join(RUN,`failure-${mode}.json`))) throw new Error('failed phase preserved; use a new run after exact owned cleanup');
  if (mode === 'seed') { assert(!existsSync(join(RUN,'seed-started.json')), 'seed already attempted; do not replay'); await seed(x); }
  if (mode === 'rpc') {
    assert(existsSync(join(RUN, 'seed.json'))); write('rpc-started.json', { at: new Date().toISOString(), head: source().observed_head });
    const { runAcceptance } = await import('./rpc.mjs'); const client = await connection(x);
    let host;
    try { const loaded = await loadHost(x, seal); host = loaded.host;
      await runAcceptance({ ...loaded, client, x, seal, fixture: read('seed.json'), write, snapshot: name => snapshot(client, name), lock: () => checkLock(c), log: record => appendFileSync(join(RUN, 'wire.jsonl'), JSON.stringify(record) + '\n') });
      write('rpc-pass.json', { scope: 'actual loopback built agent-note RPC and retained emitted host/domain; isolated bootstrap', head: source().observed_head, build: seal.build.sha256, browser: 'pending', provider_calls: 0 });
    } finally { if (host) await host.close(); await client.end({ timeout: 3 }); }
  }
  if (mode === 'serve') await serve(x, seal);
  if (mode === 'compare') { const other = process.argv[5]; assert(/^[a-z0-9][a-z0-9-]{0,63}$/.test(other)); const { assertReadOnly } = await import('./common.mjs'); assertReadOnly(read(`${label}.json`), read(`${other}.json`)); write(`compare-${label}-${other}.json`, { equal: true, public_tables: 88, scope: 'only the manually bounded window between these snapshots' }); }
  if (mode === 'snapshot') { const client = await connection(x); try { await snapshot(client, label); } finally { await client.end({ timeout: 3 }); } }
}
main().catch(error => {
  // Avoid exposing URLs/token/passwords through stdout. Detailed failure stays private in ignored run.
  let message = String(error?.stack ?? error);
  if (RUN && existsSync(join(RUN, 'private-state.json'))) {
    const x = read('private-state.json'); for (const v of [x.token, x.admin_url, x.app_url, new URL(x.admin_url).password, new URL(x.app_url).password]) message = message.replaceAll(v, '[synthetic-secret]');
  }
  if (RUN && existsSync(RUN) && !existsSync(join(RUN, `failure-${mode}.json`))) write(`failure-${mode}.json`, { message, accepted: false });
  console.error(RUN ? `${mode} failed. Acceptance is incomplete. Inspect the ignored failure receipt; do not retry writes.` : message); process.exitCode = 1;
});
